

-- ███████╗███╗░░██╗████████╗███████╗░░███╗░░░█████╗░
-- ██╔════╝████╗░██║╚══██╔══╝██╔════╝░████║░░██╔══██╗
-- █████╗░░██╔██╗██║░░░██║░░░██████╗░██╔██║░░██║░░██║
-- ██╔══╝░░██║╚████║░░░██║░░░╚════██╗╚═╝██║░░██║░░██║
-- ███████╗██║░╚███║░░░██║░░░██████╔╝███████╗╚█████╔╝
-- ╚══════╝╚═╝░░╚══╝░░░╚═╝░░░╚═════╝░╚══════╝░╚════╝░


-- DISCORD CREATOR 'https://discord.gg/wd5PszPA2p'


Config = {}

Config.Target = true  --  if use 'faòse' OX LIB TEXTUI / if use 'true' OX TARGET
Config.GarageBlip = true -- If true enable Blip Garage
Config.Scadenza = true  -- IF true The key will have an expiry date and will be automatically removed from the player's inventory when it is finished, below you can configure the minimum and maximum duration/ if false They will not expire
Config.DateFormat = "%d-%m-%Y"  --  Date format for your keys 
Config.MinDays = 1  -- The expiration date will have a minimum of this value
Config.MaxDays = 2  -- The expiration date will have a maximum of this value

Config.itemKey = 'key_ent'  -- Item for Enter in Home, IMPORTANT, HAVE A METADATA WHIT THE INFO #key_ent
Config.nameBlip = 'Proprieta In Vendita'  -- Blip In map

Config.Percentuale = 50  --  Percentual selling house
Config.Wardrobe = 'illenium-appearance'  -- if use 'fivem-appearance' FIVEM APPEARANCE / if use 'illenium-appearance' ILLENIUM APPEARANCE / if use 'krs' krs-appearance
Config.Vehicles = true  -- if use 'true' use table OWNED VEHICLES / if use 'false' use ENT HOUSE GARAGE table 
Config.TableVehicles = "vehicle" -- enter the name of the database table for saving vehicle properties
Config.UseForSaveVehiclePropeties = true -- if use 'true' use ox_lib save properties / if use 'false' use esx_framework save properties

Config.pesoStash = 23  -- maximum weight for stasg IN KG
Config.PriceKey = 1999  -- Price for buy key home
Config.TimeforCooking = 10   -- Time for Cooking 



-- █ ▀█▀ █▀▀ █▀▄▀█   █▀▀ █▀█ █▀█   █▀▀ █▀█ █▀█ █▄▀ █ █▄░█ █▀▀
-- █ ░█░ ██▄ █░▀░█   █▀░ █▄█ █▀▄   █▄▄ █▄█ █▄█ █░█ █ █░▀█ █▄█


-- remove firstItem and give secondItem

Config.cookingItem = {

    { firstItem = 'rawmeat', secondItem = 'chickenmeat', image = "https://cdn.discordapp.com/attachments/1164893336813977610/1188276292924227656/chicken_meat.png?ex=6599ef89&is=65877a89&hm=842baf84d5d2a0b84786234711ffed7184ac1877f1b51b7dd717df8598bd7a32&" },
    { firstItem = 'potato',  secondItem = 'frieschip',   image = "https://cdn.discordapp.com/attachments/1164893336813977610/1188276292693524510/fries_chip.png?ex=6599ef89&is=65877a89&hm=af9a3cb4c1810eecbdd181adb2629d953b890988be9466b8dd4cf206e0be1ed2&" },
    -- { firstItem = 'potato',  secondItem = 'frieschip',   image = "https://cdn.discordapp.com/attachments/1164893336813977610/1188276292693524510/fries_chip.png?ex=6599ef89&is=65877a89&hm=af9a3cb4c1810eecbdd181adb2629d953b890988be9466b8dd4cf206e0be1ed2&" },
    -- { firstItem = 'potato',  secondItem = 'frieschip',   image = "https://cdn.discordapp.com/attachments/1164893336813977610/1188276292693524510/fries_chip.png?ex=6599ef89&is=65877a89&hm=af9a3cb4c1810eecbdd181adb2629d953b890988be9466b8dd4cf206e0be1ed2&" }

}





-- █░█ █▀█ █░█ █▀ █▀▀
-- █▀█ █▄█ █▄█ ▄█ ██▄

Config.Housing = {

    Eclips = {
        priceHome = 134000,
        coordsEnter = vec3(-770.4937, 312.8328, 85.6981),    -- < -- Coords For ENTER      --ONLY 1
        Enter = vec3(-774.0674, 341.9777, 196.6862),         -- < -- Coords spawned        --ONLY 1
        coordsExit = vec3(-774.0674, 341.9777, 196.6862),    -- < -- Coords For EXIT    --ONLY 1
        Exit = vec3(-770.4937, 312.8328, 85.6981),           -- < -- Coords spawned     --ONLY 1
        coordStorage = vec3(-764.7521, 329.8569, 196.0860),
        coordWardrobe = vec3(-763.3616, 328.9469, 199.4863), -- < -- Coords for Wardrobe in House
        coordCooking = vec3(-778.6137, 328.1888, 196.0858), 
        coordsRadio = vec3(-779.5809, 319.2452, 195.8864), 
        coordsGarage = vec3(-791.9803, 336.9519, 85.7005), 
        coordsSpawnVehicle = vec4(-792.28, 331.44, 85.72, 178.28), 
        coordsDepositVehicle = vec3(-792.28, 331.44, 85.72), 
    },

    Integrity = {
        priceHome = 200000,
        coordsEnter = vec3(-47.4387, -586.5317, 37.9530), -- < -- Coords For ENTER
        Enter = vec3(-18.4611, -591.2622, 90.1148),   -- < -- Coords spawned
        coordsExit = vec3(-17.2645, -590.8040, 90.1148) ,-- < -- Coords For EXIT
        Exit = vec3(-47.6902, -586.1435, 37.9530) ,        -- < -- Coords spawned
        coordStorage = vec3(-28.1691, -588.5404, 90.1235), -- < -- Coords for Storage in House
        coordWardrobe = vec3(-37.5949, -583.5486, 83.9183), -- < -- Coords for Wardrobe in House
        coordCooking = vec3(-31.1014, -588.7238, 88.7122),
        coordsRadio = vec3(-40.6168, -572.0087, 88.7122),
        coordsGarage = vec3(-29.3193, -573.5084, 38.8336),
        coordsSpawnVehicle = vec4(-27.1619, -568.3889, 37.7451, 159.6969),
        coordsDepositVehicle = vec3(-27.1619, -568.3889, 37.7451),
    },

    Conker = {
        priceHome = 150000,
        coordsEnter = vec3(346.5700, 440.6891, 147.6976), -- < -- Coords For ENTER
        Enter = vec3(340.9412, 437.1798, 149.3925),   -- < -- Coords spawned
        coordsExit = vec3(340.9412, 437.1798, 149.3925) ,-- < -- Coords For EXIT
        Exit = vec3(346.5700, 440.6891, 147.6976) ,        -- < -- Coords spawned
        coordStorage = vec3(336.0303, 437.8686, 141.7708), -- < -- Coords for Storage in House
        coordWardrobe = vec3(334.2997, 428.6171, 145.5709), -- < -- Coords for Wardrobe in House
        coordCooking = vec3(340.1818, 430.9011, 149.3805),
        coordsRadio = vec3(330.5137, 422.4980, 148.9713),
        coordsGarage = vec3(350.5906, 436.1883, 147.6676),
        coordsSpawnVehicle = vec4(355.7203, 438.4257, 145.7343, 301.5833),
        coordsDepositVehicle = vec3(355.7203, 438.4257, 145.7343),
    },

    MadWayne = {
        priceHome = 133000,
        coordsEnter = vec3(-1294.3887, 454.8211, 97.4896), -- < -- Coords For ENTER
        Enter = vec3(-1289.7031, 449.2182, 97.9025)  ,   -- < -- Coords spawned
        coordsExit = vec3(-1289.7031, 449.2182, 97.9025) ,-- < -- Coords For EXIT
        Exit = vec3(-1294.3887, 454.8211, 97.4896) ,        -- < -- Coords spawned
        coordStorage = vec3(-1286.1268, 457.2208, 90.2947), -- < -- Coords for Storage in House
        coordWardrobe = vec3(-1286.3022, 437.9359, 94.0948), -- < -- Coords for Wardrobe in House
        coordCooking = vec3(-1285.5603, 444.5127, 97.8947),
        coordsRadio = vec3(-1282.7958, 432.1999, 97.4952),
        coordsGarage = vec3(-1297.8406, 454.4802, 97.6146),
        coordsSpawnVehicle = vec4(-1297.3000, 458.1468, 97.0434, 269.3590),
        coordsDepositVehicle = vec3(-1297.3000, 458.1468, 97.0434),
    },

    Sanda = {
        priceHome = 87000,
        coordsEnter = vec3(1301.0858, -573.8543, 71.7322), -- < -- Coords For ENTER
        Enter = vec3(346.4806, -1012.7468, -99.1963)  ,   -- < -- Coords spawned
        coordsExit = vec3(346.4806, -1012.7468, -99.1963) ,-- < -- Coords For EXIT
        Exit = vec3(1300.9758, -573.9640, 71.7323) ,        -- < -- Coords spawned
        coordStorage = vec3(352.6057, -998.8165, -98.8871), -- < -- Coords for Storage in House
        coordWardrobe = vec3(350.6170, -993.8025, -99.1962), -- < -- Coords for Wardrobe in House
        coordCooking = vec3(343.8467, -1002.8479, -99.1962),
        coordsRadio = vec3(338.2036, -996.5931, -99.1962),
        coordsGarage = vec3(1290.0082, -585.5796, 71.7466),
        coordsSpawnVehicle = vec4(1291.1790, -581.2528, 71.7424, 340.3363),
        coordsDepositVehicle = vec3(1291.1790, -581.2528, 71.7424),
    },

    Popolare1 = {
        priceHome = 37000,
        coordsEnter = vec3(460.7736, -1573.6766, 32.7923), -- < -- Coords For ENTER
        Enter = vec3(266.02584, -1007.537, -101.0087)  ,   -- < -- Coords spawned
        coordsExit = vec3(266.02584, -1007.537, -101.0087) ,-- < -- Coords For EXIT
        Exit = vec3(460.7736, -1573.6766, 32.7923) ,        -- < -- Coords spawned
        coordStorage = vec3(265.9900, -999.3157, -99.0087), -- < -- Coords for Storage in House
        coordWardrobe = vec3(259.8465, -1003.9293, -99.0086), -- < -- Coords for Wardrobe in House
        coordCooking = vec3(265.7617, -995.8719, -99.0087),
        coordsRadio = vec3(257.0214, -995.9047, -99.0086),
        coordsGarage = vec3(477.3162, -1548.9447, 29.2826),
        coordsSpawnVehicle = vec4(479.8391, -1542.5907, 28.7275, 229.8944),
        coordsDepositVehicle = vec3(479.8391, -1542.5907, 28.7275),
    },


}


-- █▄▀ █▀▀ █▄█ █▀   █▀ █░█ █▀█ █▀█
-- █░█ ██▄ ░█░ ▄█   ▄█ █▀█ █▄█ █▀▀


Config.keysreload = {

    {
        ped      = 's_m_m_fiboffice_02',
        position = vector3(-265.3326, -967.6927, 31.2192),  -- < -- PED POSITION FOR REQUEST keys
        heading  = 10.9304
    },

    -- {
    --     ped      = 's_m_m_fiboffice_02',
    --     position = vector3(-265.3326, -967.6927, 31.2192),  -- < -- PED POSITION FOR REQUEST keys
    --     heading  = 10.9304
    -- },
}


-- █░░ ▄▀█ █▄░█ █▀▀ █░█ ▄▀█ █▀▀ █▀▀
-- █▄▄ █▀█ █░▀█ █▄█ █▄█ █▀█ █▄█ ██▄


-- SEE README.MD FOR OTHER LANGUAGES JUST COPY AND PASTE -- 

Config.Lang = {

    -- Interaction translate

    ['OPEN_GARAGE']     = '[E] APRI GARAGE',
    ['DEPOSIT_VEH']     = '[E] DEPOSITA VEICOLO',
    ['RICHIEDI_KEY']    = '[E] RICHIEDI CHIAVI',
    ['ENTER_HOUSE']     = '[E] ENTRA IN CASA',
    ['EXIT_HOUSE']      = '[E] ESCI DI CASA',
    ['COOKING']         = '[E] PER CUCINARE',
    ['OPEN_STORAGE']    = '[E] APRI PERSONAL STORAGE',
    ['MENUMUSIC']       = '[E] ASCOLTA MUSICA',
    ['WARDROBE']        = '[E] APRI GUARDAROBA',

    -- dialog translate

    ['TITLE_INFO'] = 'INFO HOME ALERT',
    ['INVITE'] = 'RICHIESTA D\'INVITO',
    ['NO_ID'] = 'NESSUN GIOCATORE TROVATO',
    ['INVITE_REC'] = 'INVITO RICEVUTO DA GIOCATORE CON ID :',
    ['INVITE_FRIEND'] = 'INVITA IN CASA',
    ['SEND_INVITE'] = 'MANDA INVITO', 
    ['ALERT_SELLING'] = 'SEI SICURO DI VOLER VENDERE LA TUA PROPRIETA?',
    ['WARNING_ALERT'] = 'ATTENTION',
    ['INVITE_ID'] = 'ISERISCI L\'ID DEL GIOCATORE ',
    ['INVITE_FRIEND_DESC'] = 'Invita Nella tua Proprieta Un Amico',

   -- input translate

    ['SAVE_TITLE'] = 'SAVE TITLE',
    ['SAVE_URL'] = 'SAVE URL',
    ['PLAY_SONG'] = 'PLAY SONG',
    ['LIST_SONG'] = 'LISTA CANZONI',
    ['MUSIC_ACTION'] = 'AZIONI MUSICA',
    ['VOL_SONG'] = 'GESTISCI VOLUME',
    ['STOP_SONG'] = 'STOPPA CANZONE',
    ['TITLE_RADIO'] = 'ENT510 RADIO',
    ['TITLE_DIALOG_RADIO'] = 'SAVE A SONG',
    ['START_SONG'] = 'AVVIA CANZONE',
    ['DISTANCE'] = 'IMPOSTA DISTANZA',
    ['SET_DIST'] = 'GESTISCI DISTANZA',
    ['BUY_KEYS'] = 'COMPRA CHIAViI',
    ['DESC_SAVE_URL'] = 'Copia il link e incollalo [COMPATIBILE CON YT]',
    ['DESC_SAVE_TITLE'] = 'Salva un titolo di canzone come desideri che appaia',
    ['PLAY_SONG_DESC'] = 'Ascolta una canzone in compagnia',
    ['DISTANCE_DESC'] = 'Imposta la distanza di ascolto',
    
    -- menu house

    ['BUY_APPART'] = 'COMPRA APPARTAMENTO',
    ['SELL_APP'] = 'VENDI APPARTAMENTO',
    ['ENTER_HOUSE_MENU'] = 'ENTRA IN CASA',
    ['EXIT_HOUSE_MENU'] = 'ESCI DI CASA',
    ['METADATA'] = 'SCADENZA',
    ['REQUEST'] = 'RICHIESTO',
    ['HELLO'] = 'CIAO',
    ['HOME_DET'] = 'CASA ',
    ['HOME_PRICE'] = 'PREZZO ',
    ['SELL_APP_DESC'] = 'Seleziona per vendere la casa',
    ['BUY_APPART_DESC'] = 'Acquista questo appartamento e ricevi le tue chiavi personali',


    ['KEYS_OWN'] = 'CHIAVI DI :',
    ['PROP_SELL'] = 'Proprieta In Vendita:',
    ['BUY_KEY_BLIP'] = 'Recupero Chiavi',
    ['GARAGE']  = 'Garage',
    ['TITLE_GARAGE'] = 'ENT510 GARAGE',
    ['AUTO_NAME'] = 'NAME :',
    ['FUEL_PERC'] = 'FUEL :',
    ['ENTER_HOUSE_MENU_DESC'] = 'Entra dentro l\'appartamento',
    ['EXIT_HOUSE_MENU_DESC'] = 'Esci dall \'appartamento',
    
    -- Notify Translate

    ['NOTIFY_ENTER'] = 'ENTRATO CORRETTAMENTE IN CASA :',
    ['NOTIFY_EXIT'] = 'USCITO CORRETTAMENTE DA CASA :',
    ['TITLE_NOTIFY_ENTER'] = 'SUCCESS',
    ['TITLE_NOTIFY_EXIT'] = 'SUCCESS',
    ['TITLE_NOTIFY_KEYS'] = 'SUCCESS',
    ['NO_KEYS'] = 'NON HAI LE CHIAVI',
    ['ERR_HOME'] = 'HAI GIA UNA CASA',
    ['NOTIFY_NOMONEY']  = 'NON HAI SOLDI',
    ['NOT_YOU_HOME'] = 'NON E CASA TUA',
    ['KEYS_RELEASED'] = 'CHIAVI RILASCIATE CON SUCCESSO',
    ['NO_PROPER'] = 'NON HAI UNA CASA',
    ['NOTIFY_DIALOG'] = 'ERROR',
    ['NOTIFY_COOKING'] = 'ERROR',
    ['METADATA_SELLING'] = 'RIVENDITA ',
    ['HOUSE_SELLING'] = 'CASA VENDUTA CORRETTAMENTE',
    ['NOTIFY_NOSONG'] = 'NON HAI CANZONI',
    ['COOKING_NEC'] = 'PER CUCINARE TI SERVE',
    ['NOTIFY_SONG_START'] = 'CANZONE AVVIATA',
    ['NOTIFY_STOP_START'] = 'CANZONE STOPPATA',
    ['INVITE_DEN'] = 'INVITO RIFIUTATO DAL GIOCATORE CON ID :',
    ['INVITE_ACC'] = 'INVITO ACCETTATO DAL GIOCATORE CON ID :',
    ['INVITE_SENDED'] = 'INVITO INVIATO AL GIOCATORE CON ID :',
    ['NOTIFY_HOMEALR'] = 'Hai già una chiave con te',
    ['KEYS_REC']  = 'Hai ricevuto le chiavi di casa',
    ['NOTIFY_VEH_OUT'] = 'Non hai nessun veicolo all \'interno',
    ['VEH_OUT'] = 'VEICOLO GIA FUORI',
    ['NOTIFY_WARNING'] = 'WARNING',
    ['TITLE_NO_VEH'] = 'ERROR',

    ['NOTIFY_DEPOSIT'] = 'Veicolo depositato correttamente',
    ['NOTIFY_RIT'] = 'Veicolo ritirato correttamente',
    ['PLAYER_OFF'] = 'Il giocatore non è online',

    -- target label

    ['TARGET_EXIT'] = 'ESCI CASA',
    ['TARGET_ENTER'] = 'ENTRA IN CASA',
    ['TARGET_GARAGE'] = 'APRI GARAGE',
    ['TARGET_MUSIC'] = 'ASCOLTA MUSICA',
    ['TARGET_STORAGE'] = 'APRI STORAGE',
    ['TARGET_COOKING'] = 'CUCINA CIBO',
    ['TARGET_WARDR'] = 'APRI GUARDAROBA',
    ['KEYS_SHOP'] = 'KEY \'S SHOP',
    ['TARGET_KEYS'] = 'ACQUISTA CHIAVI',
    ['PRICE_KEY'] = 'PRICE:',
    ['MONEY_ID'] = '$',

    -- Garage Menu

    ['PESRONAL_VEH'] = 'VEICOLI PERSONALI',
    ['PESRONAL_VEH_DESC'] = 'Guarda i tuoi veicoli personali',

    -- Cooking menu

    ['COOKING_IT'] = 'CUCINA',
    ['RECEIVED_IT'] = 'RICEVI',
    ['TITLE_STORAGE'] = 'INVENTARIO PERSONALE',
    ['COOKING_DESC'] = 'Punta con il cursone per visualizzare l\'immagine dell\'item che ti verrà dato',

    -- Print Console Scazenza / Expire

    ['PRINT_SCAD'] = 'La scadenza della chiave è passata per l\'oggetto nell\'inventario del giocatore ',
    ['PRINT_SCAD_CHECK'] = 'La scadenza della chiave non è ancora passata per l\'oggetto nell\'inventario del giocatore ',


    -- Translate Progress Bar

    ['COOKING_ITEM'] = 'CUCINANDO ',
    ['SIGNING'] = 'FIRMANDO CONTRATTO',
    ['SELLING'] = 'CHECK PROPERTY',
    ['EXIT_HOME'] = 'USCENDO DI CASA',
    ['ENTER_HOME'] = 'APRENDO CASA',


    -- BLIP TRANSLATE

    ['YOUR_HOME'] = 'CASA TUA',
    ['YOUR_GARAGE'] = 'GARAGE TUO'
}



