
**CORRECT INSTALLATION OF THE RESOURCE**


1) INSERT *ENT510 HOUSING* IN THE PATH OF YOUR RESOURCES

2) OPEN **!INSTALLATION!** FOLDER AND INSERT THE ITEM BELOW THE ACCESS KEY WHERE THE PLAYER'S METADATA WILL BE RECORDED AND FOR ITEMS COOKING

PATH : *OX_INVENTORY / DATA / ITEMS.LUA* AND INSERT : 

```lua

    ["key_ent"] = {
		label = "Chiavi di casa",
		weight = 30,
		stack = false,
		close = true,
	},

```
PATH : CHECK **!INSTALLATION!** FOR KEYS IMAGE AND INSERT THE IMAGES IN  *OX_INVENTORY / WEB / IMAGES* 

FOR ITEMS COOKING CHECK **ox_items** IN *!INSTALLATION!* FOLDER / FOLLOW THE EXAMPLES TO MAKE THE ITEMS USABLE

    -- -- FIRST ITEM -- 

```lua

    ['rawmeat'] = {
        label = 'Carne Cruda',
        stack = true,
        weight = 140,
    },

    -- -- SECOND ITEM -- 

    ['chickenmeat'] = {
        label = 'Hamburgher Di Pollo',
        weight = 220,
        client = {
            status = { hunger = 200000 },
            anim = 'eating',
            prop = 'burger',
            usetime = 2500,
            notification = 'Hai mangiato un delizioso Hamburgher'
        },
     },

```

3) OPEN **!INSTALLATION!** FOLDER AND INSERT THE SQL FILE IN YOUR DATABASE

    -- *FOR ALL DATA HOUSING*

    CREATE TABLE IF NOT EXISTS `ent510_house` (
    `identifier` varchar(46) DEFAULT NULL,
    `house` varchar(50) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

    -- *FOR ALL DATA SONG*

    CREATE TABLE IF NOT EXISTS `ent510_song` (
    `identifier` varchar(46) DEFAULT NULL,
    `nameSong` varchar(50) DEFAULT NULL,
    `urlSong` varchar(50) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general;

    -- *FOR ALL DATA GARAGE , CHECK THE DOCS AND CONFIGURE IN SHARED / CONFIG.LUA YOUR TABLE DB* 
 
    -- *CHECK THE NAME OF YOUR TABLE VEHICLE IN YOUR DB TABLE*

    **DEFAULT ESX** = "vehicles"

    **ENT510 HOUSING** = "vehicle"
    
    CREATE TABLE IF NOT EXISTS `ent510_house_vehicles` (
    `owner` varchar(46) DEFAULT NULL,
    `plate` varchar(12) NOT NULL,
    `vehicle` longtext DEFAULT NULL,    
    `stored` tinyint(4) NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

4) GO TO **SHARED/CONFIG.LUA** AND INSTALL THE RESOURCE AS YOU WISH, FOLLOW THE DOCUMENTATION CAREFULLY, HAVING SPECIFICATIONS TO DO IN ORDER TO USE IT.

5) GO TO **SHARED/CONFIG.LUA** AND SET YOUR CLOTHING SYSTEM 

```lua

Config.Wardrobe = 'illenium-appearance'  -- if use 'fivem-appearance' FIVEM APPEARANCE / if use 'illenium-appearance' ILLENIUM APPEARANCE 

-- OR 

Config.Wardrobe = 'fivem-appearance'  -- if use 'fivem-appearance' FIVEM APPEARANCE / if use 'illenium-appearance' ILLENIUM APPEARANCE 

```

6) CHECK IN **!INSTALLATION!** FOLDER AND IN **LANGUAGE.MD**  THE LOCALES / YOU WILL BE ABLE TO FIND DIFFERENT LANGUAGES YOU JUST NEED TO COPY AND PASTE

7) NOW YOU CAN HAVE FUN, FOR ANY INFORMATION OR FOR SUPPORT / ERRORS / BUGS CONTACT A STAFFER IN THE DS: https://discord.gg/wd5PszPA2p