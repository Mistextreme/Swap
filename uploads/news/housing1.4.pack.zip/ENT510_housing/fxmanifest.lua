

fx_version 'adamant'
game 'gta5'

author 'ENT510 x HAZE x ZOXE'
version '1.0.4'
lua54 'yes'
description 'ADVANCED HOUSING SYSTEM WHIT METADATA ITEM'

shared_scripts{
    '@es_extended/imports.lua',
    "@ox_lib/init.lua",
    'shared/*'
}

client_scripts{
    'client/*'
}

escrow_ignore{
    'shared/*',
    'fxmanifest.lua'
}


dependencies {
    'es_extended',
    'ox_lib',
    'ox_inventory',
}

server_scripts{
    '@oxmysql/lib/MySQL.lua',
    'server/*'
}
dependency '/assetpacks'