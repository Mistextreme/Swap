

ITEMS KEYS 

```LUA
    ["key_ent"] = {
		label = "Chiavi di casa",
		weight = 30,
		stack = false,
		close = true,
	},


```
--  -- CHICKEN BURGER 

-- -- FIRST ITEM

-- ['rawmeat'] = {
--     label = 'Carne Cruda',
--     stack = true,
--     weight = 140,
-- },

-- -- SECOND ITEM

-- ['chickenmeat'] = {
--     label = 'Hamburgher Di Pollo',
--     weight = 220,
--     client = {
--         status = { hunger = 200000 },
--         anim = 'eating',
--         prop = 'burger',
--         usetime = 2500,
--         notification = 'Hai mangiato un delizioso Hamburgher'
--     },
-- },

-- -- FRIES CHIP

-- -- FIST ITEM 

-- ['potato'] = {
--     label = 'Patata da Friggere',
--     stack = true,
--     weight = 140,
-- },

-- -- SECOND ITEM

-- ['frieschip'] = {
--     label = 'Patatine Fritte col Bacon',
--     weight = 220,
--     client = {
--         status = { hunger = 200000 },
--         anim = 'eating',
--         prop = 'prop_food_cb_chips',
--         usetime = 2500,
--         notification = 'Hai mangiato delle buonissime patatine'
--     },
-- },
