   -- [ITALIANO] 
    
Config.Lang = {

-- Interaction translate

['OPEN_GARAGE']     = '[E] APRI GARAGE',
['DEPOSIT_VEH']     = '[E] DEPOSITA VEICOLO',
['RICHIEDI_KEY']    = '[E] RICHIEDI CHIAVI',
['ENTER_HOUSE']     = '[E] ENTRA IN CASA',
['EXIT_HOUSE']      = '[E] ESCI DI CASA',
['COOKING']         = '[E] PER CUCINARE',
['OPEN_STORAGE']    = '[E] APRI PERSONAL STORAGE',
['MENUMUSIC']       = '[E] ASCOLTA MUSICA',
['WARDROBE']        = '[E] APRI GUARDAROBA',

-- dialog translate

['TITLE_INFO'] = 'INFO HOME ALERT',
['INVITE'] = 'RICHIESTA D\'INVITO',
['NO_ID'] = 'NESSUN GIOCATORE TROVATO',
['INVITE_REC'] = 'INVITO RICEVUTO DA GIOCATORE CON ID :',
['INVITE_FRIEND'] = 'INVITA IN CASA',
['SEND_INVITE'] = 'MANDA INVITO', 
['ALERT_SELLING'] = 'SEI SICURO DI VOLER VENDERE LA TUA PROPRIETA?',
['WARNING_ALERT'] = 'ATTENTION',
['INVITE_ID'] = 'ISERISCI L\'ID DEL GIOCATORE ',
['INVITE_FRIEND_DESC'] = 'Invita Nella tua Proprieta Un Amico',

-- input translate

['SAVE_TITLE'] = 'SAVE TITLE',
['SAVE_URL'] = 'SAVE URL',
['PLAY_SONG'] = 'PLAY SONG',
['LIST_SONG'] = 'LISTA CANZONI',
['MUSIC_ACTION'] = 'AZIONI MUSICA',
['VOL_SONG'] = 'GESTISCI VOLUME',
['STOP_SONG'] = 'STOPPA CANZONE',
['TITLE_RADIO'] = 'ENT510 RADIO',
['TITLE_DIALOG_RADIO'] = 'SAVE A SONG',
['START_SONG'] = 'AVVIA CANZONE',
['DISTANCE'] = 'IMPOSTA DISTANZA',
['SET_DIST'] = 'GESTISCI DISTANZA',
['BUY_KEYS'] = 'COMPRA CHIAViI',
['DESC_SAVE_URL'] = 'Copia il link e incollalo [COMPATIBILE CON YT]',
['DESC_SAVE_TITLE'] = 'Salva un titolo di canzone come desideri che appaia',
['PLAY_SONG_DESC'] = 'Ascolta una canzone in compagnia',
['DISTANCE_DESC'] = 'Imposta la distanza di ascolto',

-- menu house

['BUY_APPART'] = 'COMPRA APPARTAMENTO',
['SELL_APP'] = 'VENDI APPARTAMENTO',
['ENTER_HOUSE_MENU'] = 'ENTRA IN CASA',
['EXIT_HOUSE_MENU'] = 'ESCI DI CASA',
['METADATA'] = 'SCADENZA',
['REQUEST'] = 'RICHIESTO',
['HELLO'] = 'CIAO',
['HOME_DET'] = 'CASA ',
['HOME_PRICE'] = 'PREZZO ',
['SELL_APP_DESC'] = 'Seleziona per vendere la casa',
['BUY_APPART_DESC'] = 'Acquista questo appartamento e ricevi le tue chiavi personali',


['KEYS_OWN'] = 'CHIAVI DI :',
['PROP_SELL'] = 'Proprieta In Vendita:',
['BUY_KEY_BLIP'] = 'Recupero Chiavi',
['GARAGE']  = 'Garage',
['TITLE_GARAGE'] = 'ENT510 GARAGE',
['AUTO_NAME'] = 'NAME :',
['FUEL_PERC'] = 'FUEL :',
['ENTER_HOUSE_MENU_DESC'] = 'Entra dentro l\'appartamento',
['EXIT_HOUSE_MENU_DESC'] = 'Esci dall \'appartamento',

-- Notify Translate

['NOTIFY_ENTER'] = 'ENTRATO CORRETTAMENTE IN CASA :',
['NOTIFY_EXIT'] = 'USCITO CORRETTAMENTE DA CASA :',
['TITLE_NOTIFY_ENTER'] = 'SUCCESS',
['TITLE_NOTIFY_EXIT'] = 'SUCCESS',
['TITLE_NOTIFY_KEYS'] = 'SUCCESS',
['NO_KEYS'] = 'NON HAI LE CHIAVI',
['ERR_HOME'] = 'HAI GIA UNA CASA',
['NOTIFY_NOMONEY']  = 'NON HAI SOLDI',
['NOT_YOU_HOME'] = 'NON E CASA TUA',
['KEYS_RELEASED'] = 'CHIAVI RILASCIATE CON SUCCESSO',
['NO_PROPER'] = 'NON HAI UNA CASA',
['NOTIFY_DIALOG'] = 'ERROR',
['NOTIFY_COOKING'] = 'ERROR',
['METADATA_SELLING'] = 'RIVENDITA ',
['HOUSE_SELLING'] = 'CASA VENDUTA CORRETTAMENTE',
['NOTIFY_NOSONG'] = 'NON HAI CANZONI',
['COOKING_NEC'] = 'PER CUCINARE TI SERVE',
['NOTIFY_SONG_START'] = 'CANZONE AVVIATA',
['NOTIFY_STOP_START'] = 'CANZONE STOPPATA',
['INVITE_DEN'] = 'INVITO RIFIUTATO DAL GIOCATORE CON ID :',
['INVITE_ACC'] = 'INVITO ACCETTATO DAL GIOCATORE CON ID :',
['INVITE_SENDED'] = 'INVITO INVIATO AL GIOCATORE CON ID :',
['NOTIFY_HOMEALR'] = 'Hai già una chiave con te',
['KEYS_REC']  = 'Hai ricevuto le chiavi di casa',
['NOTIFY_VEH_OUT'] = 'Non hai nessun veicolo all \'interno',
['VEH_OUT'] = 'VEICOLO GIA FUORI',
['NOTIFY_WARNING'] = 'WARNING',
['TITLE_NO_VEH'] = 'ERROR',

['NOTIFY_DEPOSIT'] = 'Veicolo depositato correttamente',
['NOTIFY_RIT'] = 'Veicolo ritirato correttamente',
['PLAYER_OFF'] = 'Il giocatore non è online',

-- target label

['TARGET_EXIT'] = 'ESCI CASA',
['TARGET_ENTER'] = 'ENTRA IN CASA',
['TARGET_GARAGE'] = 'APRI GARAGE',
['TARGET_MUSIC'] = 'ASCOLTA MUSICA',
['TARGET_STORAGE'] = 'APRI STORAGE',
['TARGET_COOKING'] = 'CUCINA CIBO',
['TARGET_WARDR'] = 'APRI GUARDAROBA',
['KEYS_SHOP'] = 'KEY \'S SHOP',
['TARGET_KEYS'] = 'ACQUISTA CHIAVI',
['PRICE_KEY'] = 'PRICE:',
['MONEY_ID'] = '$',

-- Garage Menu

['PESRONAL_VEH'] = 'VEICOLI PERSONALI',
['PESRONAL_VEH_DESC'] = 'Guarda i tuoi veicoli personali',

-- Cooking menu

['COOKING_IT'] = 'CUCINA',
['RECEIVED_IT'] = 'RICEVI',
['TITLE_STORAGE'] = 'INVENTARIO PERSONALE',
['COOKING_DESC'] = 'Punta con il cursone per visualizzare l\'immagine dell\'item che ti verrà dato',

-- Print Console Scazenza / Expire

['PRINT_SCAD'] = 'La scadenza della chiave è passata per l\'oggetto nell\'inventario del giocatore ',
['PRINT_SCAD_CHECK'] = 'La scadenza della chiave non è ancora passata per l\'oggetto nell\'inventario del giocatore ',


-- Translate Progress Bar

['COOKING_ITEM'] = 'CUCINANDO ',
['SIGNING'] = 'FIRMANDO CONTRATTO',
['SELLING'] = 'CHECK PROPERTY',
['EXIT_HOME'] = 'USCENDO DI CASA',
['ENTER_HOME'] = 'APRENDO CASA',


-- BLIP TRANSLATE

['YOUR_HOME'] = 'CASA TUA',
['YOUR_GARAGE'] = 'GARAGE TUO'
}

<!-- ------------------------------------------------ -->

-- [ENGLISH]


Config.Lang = {

-- Interaction translation

['OPEN_GARAGE']     = '[E] OPEN GARAGE',
['DEPOSIT_VEH']     = '[E] DEPOSIT VEHICLE',
['RICHIEDI_KEY']    = '[E] REQUEST KEYS',
['ENTER_HOUSE']     = '[E] ENTER HOUSE',
['EXIT_HOUSE']      = '[E] EXIT HOUSE',
['COOKING']         = '[E] COOKING',
['OPEN_STORAGE']    = '[E] OPEN PERSONAL STORAGE',
['MENUMUSIC']       = '[E] LISTEN TO MUSIC',
['WARDROBE']        = '[E] OPEN WARDROBE',

-- Dialog translation

['TITLE_INFO'] = 'HOME ALERT INFO',
['INVITE'] = 'INVITATION REQUEST',
['NO_ID'] = 'NO PLAYER FOUND',
['INVITE_REC'] = 'INVITATION RECEIVED FROM PLAYER WITH ID:',
['INVITE_FRIEND'] = 'INVITE TO HOUSE',
['SEND_INVITE'] = 'SEND INVITE', 
['ALERT_SELLING'] = 'ARE YOU SURE YOU WANT TO SELL YOUR PROPERTY?',
['WARNING_ALERT'] = 'ATTENTION',
['INVITE_ID'] = 'ENTER PLAYER ID ',
['INVITE_FRIEND_DESC'] = 'Invite a Friend to Your Property',

-- Input translation

['SAVE_TITLE'] = 'SAVE TITLE',
['SAVE_URL'] = 'SAVE URL',
['PLAY_SONG'] = 'PLAY SONG',
['LIST_SONG'] = 'SONG LIST',
['MUSIC_ACTION'] = 'MUSIC ACTIONS',
['VOL_SONG'] = 'MANAGE VOLUME',
['STOP_SONG'] = 'STOP SONG',
['TITLE_RADIO'] = 'ENT510 RADIO',
['TITLE_DIALOG_RADIO'] = 'SAVE A SONG',
['START_SONG'] = 'START SONG',
['DISTANCE'] = 'SET DISTANCE',
['SET_DIST'] = 'MANAGE DISTANCE',
['BUY_KEYS'] = 'BUY KEYS',
['DESC_SAVE_URL'] = 'Copy the link and paste it [COMPATIBLE WITH YT]',
['DESC_SAVE_TITLE'] = 'Save a song title as you want it to appear',
['PLAY_SONG_DESC'] = 'Listen to a song together',
['DISTANCE_DESC'] = 'Set listening distance',

-- House menu

['BUY_APPART'] = 'BUY APARTMENT',
['SELL_APP'] = 'SELL APARTMENT',
['ENTER_HOUSE_MENU'] = 'ENTER HOUSE',
['EXIT_HOUSE_MENU'] = 'EXIT HOUSE',
['METADATA'] = 'EXPIRY',
['REQUEST'] = 'REQUESTED',
['HELLO'] = 'HELLO',
['HOME_DET'] = 'HOME ',
['HOME_PRICE'] = 'PRICE ',
['SELL_APP_DESC'] = 'Select to sell the house',
['BUY_APPART_DESC'] = 'Buy this apartment and receive your personal keys',


['KEYS_OWN'] = 'KEYS OF :',
['PROP_SELL'] = 'Property For Sale:',
['BUY_KEY_BLIP'] = 'Key Retrieval',
['GARAGE']  = 'Garage',
['TITLE_GARAGE'] = 'ENT510 GARAGE',
['AUTO_NAME'] = 'NAME :',
['FUEL_PERC'] = 'FUEL :',
['ENTER_HOUSE_MENU_DESC'] = 'Enter the apartment',
['EXIT_HOUSE_MENU_DESC'] = 'Exit the apartment',

-- Notify Translation

['NOTIFY_ENTER'] = 'ENTERED HOUSE SUCCESSFULLY:',
['NOTIFY_EXIT'] = 'EXITED HOUSE SUCCESSFULLY:',
['TITLE_NOTIFY_ENTER'] = 'SUCCESS',
['TITLE_NOTIFY_EXIT'] = 'SUCCESS',
['TITLE_NOTIFY_KEYS'] = 'SUCCESS',
['NO_KEYS'] = 'YOU DON\'T HAVE KEYS',
['ERR_HOME'] = 'YOU ALREADY HAVE A HOUSE',
['NOTIFY_NOMONEY']  = 'YOU DON\'T HAVE MONEY',
['NOT_YOU_HOME'] = 'IT\'S NOT YOUR HOUSE',
['KEYS_RELEASED'] = 'KEYS RELEASED SUCCESSFULLY',
['NO_PROPER'] = 'YOU DON\'T HAVE A HOUSE',
['NOTIFY_DIALOG'] = 'ERROR',
['NOTIFY_COOKING'] = 'ERROR',
['METADATA_SELLING'] = 'RESALE ',
['HOUSE_SELLING'] = 'HOUSE SOLD SUCCESSFULLY',
['NOTIFY_NOSONG'] = 'YOU DON\'T HAVE SONGS',
['COOKING_NEC'] = 'YOU NEED TO COOK',
['NOTIFY_SONG_START'] = 'SONG STARTED',
['NOTIFY_STOP_START'] = 'SONG STOPPED',
['INVITE_DEN'] = 'INVITATION DECLINED BY PLAYER WITH ID:',
['INVITE_ACC'] = 'INVITATION ACCEPTED BY PLAYER WITH ID:',
['INVITE_SENDED'] = 'INVITATION SENT TO PLAYER WITH ID:',
['NOTIFY_HOMEALR'] = 'You already have a key with you',
['KEYS_REC']  = 'You received the house keys',
['NOTIFY_VEH_OUT'] = 'You have no vehicles inside',
['VEH_OUT'] = 'VEHICLE ALREADY OUT',
['NOTIFY_WARNING'] = 'WARNING',
['TITLE_NO_VEH'] = 'ERROR',

['NOTIFY_DEPOSIT'] = 'Vehicle deposited successfully',
['NOTIFY_RIT'] = 'Vehicle withdrawn successfully',
['PLAYER_OFF'] = 'The player is not online',

-- Target Label

['TARGET_EXIT'] = 'EXIT HOUSE',
['TARGET_ENTER'] = 'ENTER HOUSE',
['TARGET_GARAGE'] = 'OPEN GARAGE',
['TARGET_MUSIC'] = 'LISTEN TO MUSIC',
['TARGET_STORAGE'] = 'OPEN STORAGE',
['TARGET_COOKING'] = 'COOK FOOD',
['TARGET_WARDR'] = 'OPEN WARDROBE',
['KEYS_SHOP'] = 'KEY\'S SHOP',
['TARGET_KEYS'] = 'BUY KEYS',
['PRICE_KEY'] = 'PRICE:',
['MONEY_ID'] = '$',

-- Garage Menu

['PERSONAL_VEH'] = 'PERSONAL VEHICLES',
['PERSONAL_VEH_DESC'] = 'View your personal vehicles',

-- Cooking Menu

['COOKING_IT'] = 'COOK',
['RECEIVED_IT'] = 'RECEIVE',
['TITLE_STORAGE'] = 'PERSONAL INVENTORY',
['COOKING_DESC'] = 'Point the cursor to view the image of the item you will receive',

-- Print Console Expiry

['PRINT_SCAD'] = 'The key expiry has passed for the item in the player\'s inventory ',
['PRINT_SCAD_CHECK'] = 'The key expiry has not yet passed for the item in the player\'s inventory ',


-- Translate Progress Bar

['COOKING_ITEM'] = 'COOKING ',
['SIGNING'] = 'SIGNING CONTRACT',
['SELLING'] = 'CHECK PROPERTY',
['EXIT_HOME'] = 'EXITING HOUSE',
['ENTER_HOME'] = 'OPENING HOUSE',


-- BLIP TRANSLATE

['YOUR_HOME'] = 'YOUR HOUSE',
['YOUR_GARAGE'] = 'YOUR GARAGE'
}



<!-- ------------------------------------------------ -->

[FRANCAIS]

Config.Lang = {

-- Traduction des interactions

['OPEN_GARAGE']     = '[E] OUVRIR LE GARAGE',
['DEPOSIT_VEH']     = '[E] DÉPOSER LE VÉHICULE',
['RICHIEDI_KEY']    = '[E] DEMANDER LES CLÉS',
['ENTER_HOUSE']     = '[E] ENTRER DANS LA MAISON',
['EXIT_HOUSE']      = '[E] SORTIR DE LA MAISON',
['COOKING']         = '[E] CUISINER',
['OPEN_STORAGE']    = '[E] OUVRIR LE STOCKAGE PERSONNEL',
['MENUMUSIC']       = '[E] ÉCOUTER DE LA MUSIQUE',
['WARDROBE']        = '[E] OUVRIR LE DRESSING',

-- Traduction des dialogues

['TITLE_INFO'] = 'ALERTE INFO DOMICILE',
['INVITE'] = 'DEMANDE D\'INVITATION',
['NO_ID'] = 'AUCUN JOUEUR TROUVÉ',
['INVITE_REC'] = 'INVITATION REÇUE DU JOUEUR AVEC L\'ID :',
['INVITE_FRIEND'] = 'INVITER À LA MAISON',
['SEND_INVITE'] = 'ENVOYER UNE INVITATION', 
['ALERT_SELLING'] = 'ÊTES-VOUS SÛR DE VOULOIR VENDRE VOTRE PROPRIÉTÉ ?',
['WARNING_ALERT'] = 'ATTENTION',
['INVITE_ID'] = 'ENTRER L\'ID DU JOUEUR ',
['INVITE_FRIEND_DESC'] = 'Invitez un ami dans votre propriété',

-- Traduction des entrées

['SAVE_TITLE'] = 'ENREGISTRER LE TITRE',
['SAVE_URL'] = 'ENREGISTRER L\'URL',
['PLAY_SONG'] = 'LIRE UNE CHANSON',
['LIST_SONG'] = 'LISTE DES CHANSONS',
['MUSIC_ACTION'] = 'ACTIONS MUSICALES',
['VOL_SONG'] = 'GÉRER LE VOLUME',
['STOP_SONG'] = 'ARRÊTER LA CHANSON',
['TITLE_RADIO'] = 'RADIO ENT510',
['TITLE_DIALOG_RADIO'] = 'ENREGISTRER UNE CHANSON',
['START_SONG'] = 'DÉMARRER LA CHANSON',
['DISTANCE'] = 'RÉGLER LA DISTANCE',
['SET_DIST'] = 'GÉRER LA DISTANCE',
['BUY_KEYS'] = 'ACHETER DES CLÉS',
['DESC_SAVE_URL'] = 'Copiez le lien et collez-le [COMPATIBLE AVEC YT]',
['DESC_SAVE_TITLE'] = 'Enregistrez un titre de chanson comme vous le souhaitez',
['PLAY_SONG_DESC'] = 'Écoutez une chanson en compagnie',
['DISTANCE_DESC'] = 'Définissez la distance d\'écoute',

-- Menu de la maison

['BUY_APPART'] = 'ACHETER UN APPARTEMENT',
['SELL_APP'] = 'VENDRE UN APPARTEMENT',
['ENTER_HOUSE_MENU'] = 'ENTRER DANS LA MAISON',
['EXIT_HOUSE_MENU'] = 'SORTIR DE LA MAISON',
['METADATA'] = 'ÉCHEANCE',
['REQUEST'] = 'DEMANDÉ',
['HELLO'] = 'SALUT',
['HOME_DET'] = 'MAISON ',
['HOME_PRICE'] = 'PRIX ',
['SELL_APP_DESC'] = 'Sélectionnez pour vendre la maison',
['BUY_APPART_DESC'] = 'Achetez cet appartement et recevez vos clés personnelles',


['KEYS_OWN'] = 'CLÉS DE :',
['PROP_SELL'] = 'Propriété À Vendre :',
['BUY_KEY_BLIP'] = 'Récupération des Clés',
['GARAGE']  = 'Garage',
['TITLE_GARAGE'] = 'GARAGE ENT510',
['AUTO_NAME'] = 'NOM :',
['FUEL_PERC'] = 'CARBURANT :',
['ENTER_HOUSE_MENU_DESC'] = 'Entrer dans l\'appartement',
['EXIT_HOUSE_MENU_DESC'] = 'Sortir de l\'appartement',

-- Notification

['NOTIFY_ENTER'] = 'ENTRÉ DANS LA MAISON AVEC SUCCÈS :',
['NOTIFY_EXIT'] = 'SORTI DE LA MAISON AVEC SUCCÈS :',
['TITLE_NOTIFY_ENTER'] = 'SUCCÈS',
['TITLE_NOTIFY_EXIT'] = 'SUCCÈS',
['TITLE_NOTIFY_KEYS'] = 'SUCCÈS',
['NO_KEYS'] = 'VOUS N\'AVEZ PAS DE CLÉS',
['ERR_HOME'] = 'VOUS AVEZ DÉJÀ UNE MAISON',
['NOTIFY_NOMONEY']  = 'VOUS N\'AVEZ PAS D\'ARGENT',
['NOT_YOU_HOME'] = 'CE N\'EST PAS VOTRE MAISON',
['KEYS_RELEASED'] = 'CLÉS LIBÉRÉES AVEC SUCCÈS',
['NO_PROPER'] = 'VOUS N\'AVEZ PAS DE MAISON',
['NOTIFY_DIALOG'] = 'ERREUR',
['NOTIFY_COOKING'] = 'ERREUR',
['METADATA_SELLING'] = 'REVENTE ',
['HOUSE_SELLING'] = 'MAISON VENDUE AVEC SUCCÈS',
['NOTIFY_NOSONG'] = 'VOUS N\'AVEZ PAS DE CHANSONS',
['COOKING_NEC'] = 'POUR CUISINER, VOUS AVEZ BESOIN DE',
['NOTIFY_SONG_START'] = 'CHANSON DÉMARRÉE',
['NOTIFY_STOP_START'] = 'CHANSON ARRÊTÉE',
['INVITE_DEN'] = 'INVITATION REFUSÉE PAR LE JOUEUR AVEC L\'ID :',
['INVITE_ACC'] = 'INVITATION ACCEPTÉE PAR LE JOUEUR AVEC L\'ID :',
['INVITE_SENDED'] = 'INVITATION ENVOYÉE AU JOUEUR AVEC L\'ID :',
['NOTIFY_HOMEALR'] = 'Vous avez déjà une clé avec vous',
['KEYS_REC']  = 'Vous avez reçu les clés de la maison',
['NOTIFY_VEH_OUT'] = 'Vous n\'avez aucun véhicule à l\'intérieur',
['VEH_OUT'] = 'VÉHICULE DÉJÀ SORTI',
['NOTIFY_WARNING'] = 'AVERTISSEMENT',
['TITLE_NO_VEH'] = 'ERREUR',

['NOTIFY_DEPOSIT'] = 'Véhicule déposé avec succès',
['NOTIFY_RIT'] = 'Véhicule retiré avec succès',
['PLAYER_OFF'] = 'Le joueur n\'est pas en ligne',

-- Étiquette de la cible

['TARGET_EXIT'] = 'SORTIR DE LA MAISON',
['TARGET_ENTER'] = 'ENTRER DANS LA MAISON',
['TARGET_GARAGE'] = 'OUVRIR LE GARAGE',
['TARGET_MUSIC'] = 'ÉCOUTER DE LA MUSIQUE',
['TARGET_STORAGE'] = 'OUVRIR LE STOCKAGE',
['TARGET_COOKING'] = 'CUIRE DE LA NOURRITURE',
['TARGET_WARDR'] = 'OUVRIR LE DRESSING',
['KEYS_SHOP'] = 'BOUTIQUE DE CLÉS',
['TARGET_KEYS'] = 'ACHETER DES CLÉS',
['PRICE_KEY'] = 'PRIX :',
['MONEY_ID'] = '$',

-- Menu du garage

['PERSONAL_VEH'] = 'VÉHICULES PERSONNELS',
['PERSONAL_VEH_DESC'] = 'Voir vos véhicules personnels',

-- Menu de cuisine

['COOKING_IT'] = 'CUIRE',
['RECEIVED_IT'] = 'RECEVOIR',
['TITLE_STORAGE'] = 'INVENTAIRE PERSONNEL',
['COOKING_DESC'] = 'Pointez le curseur pour voir l\'image de l\'objet que vous recevrez',

-- Affichage Console Expiry

['PRINT_SCAD'] = 'L\'échéance de la clé a expiré pour l\'objet dans l\'inventaire du joueur ',
['PRINT_SCAD_CHECK'] = 'L\'échéance de la clé n\'a pas encore expiré pour l\'objet dans l\'inventaire du joueur ',


-- Barre de progression

['COOKING_ITEM'] = 'EN CUISSON ',
['SIGNING'] = 'SIGNATURE DU CONTRAT',
['SELLING'] = 'VÉRIFICATION DE LA PROPRIÉTÉ',
['EXIT_HOME'] = 'SORTIE DE LA MAISON',
['ENTER_HOME'] = 'OUVERTURE DE LA MAISON',


-- Traduction des blips

['YOUR_HOME'] = 'VOTRE MAISON',
['YOUR_GARAGE'] = 'VOTRE GARAGE'
}

