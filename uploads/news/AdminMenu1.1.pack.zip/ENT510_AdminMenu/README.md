DOCS: https://legacy-script.gitbook.io/legacy-script/

Interface / Entity debug by PS ADMIN MENU -- 