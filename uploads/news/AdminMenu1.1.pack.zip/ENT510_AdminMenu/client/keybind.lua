function CaricaKeybind()
    loadKeybind()
end

function loadKeybind()
    local keybind = lib.addKeybind({
        name = 'respects',
        description = 'press F to pay respects',
        defaultKey = Config.Key,
        onPressed = function(self)
            CreatePlayerMenu()
            lib.showMenu('player')
        end,
        onReleased = function(self)
            print(('Catroia Rilascia sta merda'))
        end
    })
end
