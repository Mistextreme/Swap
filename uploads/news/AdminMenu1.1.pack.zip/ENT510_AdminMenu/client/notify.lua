function ShowNotification(title, description, icon, iconColor)
        lib.notify({
            id = 'some_identifier',
            title = title,
            description = description,
            position = 'top-left',
    
            style = {
                backgroundColor = '#2C3E50',
                color = '#FFFFFF', 
                border = '1px solid #2C3E50',  
                boxShadow = '0px 4px 8px rgba(0, 0, 0, 0.2)', 
                borderRadius = '8px', 
                padding = '16px', 
                ['.title'] = {
                    fontSize = '18px', 
                    fontWeight = 'bold',
                    marginBottom = '8px', 
                    color = '#FFFFFF', 
                },
                ['.icon'] = {
                    marginRight = '12px', 
                    color = iconColor or '#FFFFFF', 
                },
                ['.description'] = {
                    color = '#BDC3C7', 
                    fontSize = '14px',  
                }
            },
            icon = icon or 'info-circle',
            iconColor = iconColor or '#FFFFFF', 
            
        })
end


