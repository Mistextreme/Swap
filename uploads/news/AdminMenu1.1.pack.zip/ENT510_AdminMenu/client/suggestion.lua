--GIVE CAR

function loadSuggestion()
    TriggerEvent('chat:commands:add', '/givecar', Lang.GiveCarTitle .. ' | ' .. Lang.GiveCarDesc, {
        { name = "id",         help = Lang.IDGiocatore },
        { name = "nome_veicolo", help = Lang.ModelloVeicolo },
    })

    TriggerEvent('chat:addSuggestion', '/givecar', Lang.GiveCarDesc, {
        { name = "id",         help = Lang.IDGiocatore },
        { name = "nome_veicolo", help = Lang.ModelloVeicolo },
    })

    -- REFRESH BLIP

    TriggerEvent('chat:addSuggestion', '/inizblip', "Aggiorna i blip sul server", {})



    TriggerEvent('chat:addSuggestion', '/adminmenu', "Apri Admin Menu", {})



    -- BAN PLAYER

    TriggerEvent('chat:addSuggestion', '/ban', "Banna un giocatore dal server", {
        { name = "playerId", help = "ID del giocatore da bannare" },
        { name = "motivo", help = "Motivo del ban" }
    })
end
