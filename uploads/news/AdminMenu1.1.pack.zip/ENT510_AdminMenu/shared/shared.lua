Config = {}

-- Group Allwed For Access Admin Menu
Config.GroupAllowed = {
    ['user'] = false,
    ['admin'] = true,
    ['owner'] = true,

}
-- Various Info
Config.DebugEnabled = false                            -- Print for Detect error
Config.DebugSql = false                                -- Print for Detect ban detail via console
Config.PositionMenu =
'top-right'                                            -- 'top-left' or 'top-right' or 'bottom-left' or 'bottom-right' - Default: 'top-left'
Config.TimeCheckBan = 10                               -- Time to check the ban in code
-- Command
Config.CommandOpenMenu = 'adminmenu'                   -- Command open Admmin menu
Config.KeyBindMenu = "F6"                              -- Keybind Admin Menu
Config.RefreshCommandBlip = 'inizblip'                 -- Command to refresh blip
Config.CommandGiveaCar = 'givecar'                     -- Give Car Command (givecar [id] [vehicle])
Config.BanCommand = 'ban'                              -- Whit Command dont have a screenshot
Config.TableVehicle = 'owned_vehicles'                 -- You owned_vehicles Table, Default is 'owned_vehicles'
-- Color RGB for laser in debug entity (dev options)
Config.LaserColor = { r = 0, g = 255, b = 0, a = 200 } -- Color for laser RGB
--Fuel System
Config.SystemFuel = 'ox'                               -- Implement your system fuel | for ox fuel use 'ox'

-- Refuel system if use ox fuel don touch / if use another fuel put your  export in line 42

function SistemaBenzina()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)

    if DoesEntityExist(vehicle) and GetPedInVehicleSeat(vehicle, -1) == playerPed then
        if Config.SystemFuel == 'ox' then
            local fuel = Entity(vehicle).state.fuel
            Entity(vehicle).state.fuel = 100.0 -- Refuel percentage on Refueling event / If use ox fuel dont touch
        end
        if Config.SystemFuel == 'custom' then
            print('put your export for system fuel')                                                         -- Import your export
        end
        ShowNotification(Lang.NotifySuccess, Lang.VehicleRefuelSuccess, 'fa-solid fa-gas-pump', 'grey')      -- Refuel Notification
    else
        ShowNotification(Lang.NotifyError, Lang.MustBeInsideVehicleToRefuel, 'fa-solid fa-gas-pump', 'grey') -- Inside Car Refuel Notification
    end
end

-- Set your export for clothing menu / momentanly support illenium / fivem appearance

Config.SkinMenu = 'illenium' -- 'illenium' Use Illenium Appearnce 'fivem-appearance' Use Fivem Appearance /

function OpenSkinMenu(Target, id)
    if Config.SkinMenu == 'illenium' then
        Target.triggerEvent("illenium-appearance:client:openClothingShop", function(isPedMenu)
            if type(isPedMenu) == "table" then
                isPedMenu = false
            end
        end)
    end
    if Config.SkinMenu == 'custom' then
        print('Put your export')
    end
end

-- Vehicle List for Rapid Vehicle Menu
Config.VehicleFast = {
    'kuruma',
    'panto',
    't20',

}

-- If you want to remove or add times, just follow the examples,
Config.TimeFast = {
    { label = "00:00", value = 0 },
    { label = "01:00", value = 1 },
    { label = "02:00", value = 2 },
    { label = "03:00", value = 3 },
    { label = "04:00", value = 4 },
    { label = "05:00", value = 5 },
    { label = "06:00", value = 6 },
    { label = "07:00", value = 7 },
    { label = "08:00", value = 8 },
    { label = "09:00", value = 9 },
    { label = "10:00", value = 10 },
    { label = "11:00", value = 11 },
    { label = "12:00", value = 12 },
    { label = "13:00", value = 13 },
    { label = "14:00", value = 14 },
    { label = "15:00", value = 15 },
    { label = "16:00", value = 16 },
    { label = "17:00", value = 17 },
    { label = "18:00", value = 18 },
    { label = "19:00", value = 19 },
    { label = "20:00", value = 20 },
    { label = "21:00", value = 21 },
    { label = "22:00", value = 22 },
    { label = "23:00", value = 23 },
}

-- Distance Clear area
Config.DistClearArea = {
    { value = '10.0',  label = '10.0 metri' },
    { value = '30.0',  label = '30.0 metri' },
    { value = '40.0',  label = '40.0 metri' },
    { value = '50.0',  label = '50.0 metri' },
    { value = '60.0',  label = '60.0 metri' },
    { value = '70.0',  label = '70.0 metri' },
    { value = '80.0',  label = '80.0 metri' },
    { value = '90.0',  label = '90.0 metri' },
    { value = '100.0', label = '100.0 metri' }
}

-- Distance Clear Vehicle
Config.DistCLearVehicle = {
    { value = '10.0',  label = '10.0 metri' },
    { value = '30.0',  label = '30.0 metri' },
    { value = '40.0',  label = '40.0 metri' },
    { value = '50.0',  label = '50.0 metri' },
    { value = '60.0',  label = '60.0 metri' },
    { value = '70.0',  label = '70.0 metri' },
    { value = '80.0',  label = '80.0 metri' },
    { value = '90.0',  label = '90.0 metri' },
    { value = '100.0', label = '100.0 metri' }
}



-- Logo Webhook
Config.LogoServerWebhook =
'https://cdn.discordapp.com/attachments/1184234727490719846/1197264586739564624/esxLogo.png?ex=65baa289&is=65a82d89&hm=f8049ba9af86f310028af8c70d1f79a986f06e2d21817766db562071f7b0d2d7&' -- logo webhook
-- Webhook GiveCar
Config.Webhook =
'https://discord.com/api/webhooks/1165725823907663924/453LbjX9S4-ckKJp_Nn6JRCNbwi8TygGJ4cuFwyJt_Rjj0B4SkDFEypzhjKBpYwRuMDv' -- Webhook for givecar
-- Webhook Ban System
Config.WebhookBan =
'https://discord.com/api/webhooks/1200838652901732472/adxwo-gNuh8qHO-hdifU77Xzbf1RV3_ZeQhXr_USzCs5jUx0curnu605BKL6xbpcE9H0' -- This is for the player banned
Config.WebhookBanLogin =
'https://discord.com/api/webhooks/1200838652901732472/adxwo-gNuh8qHO-hdifU77Xzbf1RV3_ZeQhXr_USzCs5jUx0curnu605BKL6xbpcE9H0' -- This is for the player banned can try to enter in server
-- Webhook Request Screen
Config.WebhookRichiestaScreen =
'https://discord.com/api/webhooks/1200507053215588502/uOgv6Noa2kwJatysL_2LhHb3jU8laY4iCTHVKZEiK57z9s9dPx6XZSZwpaAnYj5aw5QC' -- WEbhook for request screen



-- Ars Ambulance Job https://github.com/Arius-Development/ars_ambulancejob

-- Revive event
function RevivePlayer(id)
    local data = {}
    data.revive = true
    TriggerClientEvent('ars_ambulancejob:healPlayer', id, data)
end

-- Heal Event
function HealPlayer(id)
    local data = {}
    data.heal = true
    TriggerClientEvent('ars_ambulancejob:healPlayer', id, data)
end

-- Insert logo in 'url' / Be careful touching if you don't know what you are doing

Config.IdCard = [==[
    {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.3",
        "type": "AdaptiveCard",
        "body": [
        {
            "type": "Image",
            "url": "https://cdn.discordapp.com/attachments/1184234727490719846/1197264586739564624/esxLogo.png?ex=65c3dd09&is=65b16809&hm=47a6bbd7673b7723b62525a62665c01cf39dd90aeed57af24bfdece14590c873&",
            "size": "Medium",
            "horizontalAlignment": "Center",
            "spacing": "Medium"
        },
        {
            "type": "TextBlock",
            "text": "ENT510 Admin Menu",
            "weight": "Bolder",
            "size": "Large",
            "horizontalAlignment": "Center",
            "spacing": "Medium"
        },
        {
            "type": "TextBlock",
            "text": "Checking your history...please wait  %s",
            "wrap": true,
            "horizontalAlignment": "Center",
            "spacing": "Medium"
        },
        {
            "type": "TextBlock",
            "text": " Link Web",
            "horizontalAlignment": "Center",
            "spacing": "Large"
        }
        ],
        "actions": [
        {
            "type": "Action.OpenUrl",
            "title": "Website",
            "url": "https://anosmus.github.io/Zoxe-Home/"
        },
        {
            "type": "Action.OpenUrl",
            "title": "Youtube",
            "url": "https://www.youtube.com/channel/UCdzRZNtXC1GfmgBu56fXJ2g"
        },
        {
            "type": "Action.OpenUrl",
            "title": "Discord",
            "url": "https://discord.gg/avJYpPCfuG"
        }
        ],
        "horizontalAlignment": "Center"
    }
]==]
