fx_version 'adamant'
game 'gta5'
lua54 'yes'

author 'ENT510'
version '1.1'

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'shared/*.lua',
}

client_scripts {
    'client/*.lua',
    'function/noclip/utils.lua',
    'function/noclip/config.lua',
    'function/noclip/camera.lua',
    'function/noclip/main.lua',
    'function/laser/laser.lua',

}

ui_page 'html/index.html'

files {
    'html/**',
    'data/ped.lua',
    'data/object.lua',
}

server_scripts {
    'server/*.lua',
    '@oxmysql/lib/MySQL.lua'
}


escrow_ignore {

    'shared/*.lua',
    'data/*.lua',
    'function/laser/laser.lua',
    'client/keybind.lua',
    'client/notify.lua',
    'client/suggestion.lua'
}
dependency '/assetpacks'