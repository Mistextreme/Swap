fx_version 'adamant'
game 'gta5'
lua54 'yes'


author 'ENT510'
version '1.3'

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'shared/*.lua'
}

client_scripts {
    'client/*.lua',
    'client/function/*.lua',
}

server_scripts {
    'server/*.lua',
    '@oxmysql/lib/MySQL.lua',
}

files {
    "img/cars/*.png",
}


escrow_ignore {
    'client/addon_car.lua',
    'client/c_editable.lua',
    'server/sv_editable.lua',
    'shared/*.lua'

}

dependency '/assetpacks'