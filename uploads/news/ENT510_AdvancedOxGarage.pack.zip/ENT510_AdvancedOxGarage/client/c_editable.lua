-- Notification Client Side

function NotificaSuccess(msg)
    lib.notify({
        id = 'success',
        title = 'Success',
        description = msg,
        type = 'inform',
        position = Config.PositionNotification,
        duration = 3 * 1000,
        icon = 'fa-regular fa-circle-check',
        iconColor = 'white',
       
    })
end

function NotificaWarning(msg)
    lib.notify({
        id = 'warning',
        title = 'Warning',
        description = msg,
        type = 'warning',
        position = Config.PositionNotification,
        duration = 3 * 1000,
        icon = 'fa-solid fa-triangle-exclamation',
        iconColor = 'yellow'
    })
end

-- Description And Suggestion for Command

TriggerEvent("chat:addSuggestion", "/carlist", "Display vehicle statistics") 

TriggerEvent("chat:addSuggestion", "/givecarkey", "Grant a key for a vehicle", {
    { name = "playerId", help = "Player ID" },
    { name = "plate", help = "Vehicle Plate" }
})


-- Set Custom Lcokpick


local bl_ui                   = exports.bl_ui

function SetLockPick()
    return bl_ui:CircleProgress(3, 50) -- Byte Skillcheck https://docs.byte-labs.net/bl_ui/games
end

function SetLockPickOx()
    return lib.skillCheck({ 'easy', 'easy', { areaSize = 60, speedMultiplier = 1 }, 'easy' }, { 'd' }) -- Ox Lib Skill Check
end
