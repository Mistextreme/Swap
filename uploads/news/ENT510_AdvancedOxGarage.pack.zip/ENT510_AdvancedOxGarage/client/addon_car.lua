CreateThread(function()
    AddTextEntry('supra1998', 'supra1998')
    AddTextEntry('exc530sm', 'exc530sm')
end)



