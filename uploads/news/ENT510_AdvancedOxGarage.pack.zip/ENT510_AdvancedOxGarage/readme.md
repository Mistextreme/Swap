# Items

    ['vehicle_key'] = {
    	label = 'Car Keys',
    	weight = 50,
    	stack = false
    },

    	['lockpick'] = {
    	label = 'LockPick',
    	weight = 160,
    },

# Exports

exports.ENT510_AdvancedOxGarage:recoveryKey({plate = 'yourvalue'}) -- Give Vehicle Key

# Example:

exports.ENT510_AdvancedOxGarage:recoveryKey({plate = Plate}) -- Example Give Vehicle Key
