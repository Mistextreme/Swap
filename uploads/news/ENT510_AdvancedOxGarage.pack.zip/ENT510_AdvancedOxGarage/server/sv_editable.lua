function NotificaSuccessServer(source, msg)
    local _source = source
    TriggerClientEvent('ox_lib:notify', _source, {
        title = 'Success',
        description = msg,
        type = 'inform',
        position = Config.PositionNotification,
        icon = 'fa-regular fa-circle-check',
        duration = 3 * 1000,
        iconColor = 'white',
    })
end

function NotificaSuccessWarning(source ,msg)
    local _source = source
    TriggerClientEvent('ox_lib:notify', _source, {
        title = 'Warning',
        description = msg,
        type = 'inform',
        position = Config.PositionNotification,
        icon = 'fa-solid fa-triangle-exclamation',
        duration = 3 * 1000,
        iconColor = 'yellow',
    })
end