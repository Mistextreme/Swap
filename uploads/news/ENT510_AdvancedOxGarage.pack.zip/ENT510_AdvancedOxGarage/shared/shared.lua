Config                        = {}

-- Configuration
Config.DebugEnabled           = true                      -- Print In Console For Detect Error
Config.PositionNotification   = 'top'                     --'top' or 'top-right' or 'top-left' or 'bottom' or 'bottom-right' or 'bottom-left' or 'center-right' or 'center-left' Default: 'top-right'
Config.PositionMenuOx         = 'top-left'                --'top-left' or 'top-right' or 'bottom-left' or 'bottom-right' Default: 'top-left'
Config.MoneyItem              = 'money'                   -- Money Item
Config.PriceRestoreVehicle    = 3000                      -- Price For Restore Vehicle Only if he's around and not impounded
Config.TaskWarpPedIntoVehicle = true                      -- If true when spawn a vehicle teleport a player in Vehicle
Config.MultiBlipEnabled       = true                      -- If false All garages will be called a generic name. If true, each garage will have the same name and Blip
Config.ScenarioPrewievCamera  = "WORLD_HUMAN_GOLF_PLAYER" -- Scenario Camera Prewiev
Config.DrawTextAboveHead      = false                     -- If true Above head ped have a name of garage (Resmon higher)
-- Webhook
Config.WebhookEnabled         = true
Config.WebhookUrl             = "https://discord.com/api/webhooks/1165725823907663924/453LbjX9S4-ckKJp_Nn6JRCNbwi8TygGJ4cuFwyJt_Rjj0B4SkDFEypzhjKBpYwRuMDv"
Config.WebhookPhotoLogo       = 'https://cdn.discordapp.com/attachments/1184234727490719846/1197264586739564624/esxLogo.png?ex=65f20189&is=65df8c89&hm=3e2bb01baff4e9d2ddea9377773907cb2c5ec81757cfcd5e2e31b35e88c0c21a&'
-- Interaction
Config.TargetDepositEnabled   = true                              -- If true Deposit Vehicle With Target if False use A Marker
-- Vehicle List Menu
Config.PermsOpenVehList       = false                              --  if true Enable Only for Job
Config.CommandOpenVehList     = 'carlista'                         -- Command Open Car list
Config.VehListJobName         = 'police'                           -- Job name / If Config.PermsOpenVehList = true only job whit name specified in this line will open the menu / if false all open vehlist menu
-- Car Key
Config.UseCarKeys             = true                               -- If True Use Key Lock
Config.ShopKeyEnabled         = true                               -- If True Shop Keys is Enabled
Config.ItemCarKey             = 'vehicle_key'                            -- Items Key
Config.TargetKeyEnable        = false                               -- If true Use Target for Open / Close Veh if false Use Keybind
Config.KeyBindLockVeh         = 'H'                                -- Keybind Lock vehicle
Config.PriceKeyVehicle        = 2000                               -- Price For Request Key
-- LockPick
Config.SkillCheckType         = 'byte'                             -- ox or byte
Config.ItemLockPick           = 'lockpick'                         -- Item LockPick
Config.BonesToTargetLockPick  = { 'door_dside_f', 'door_pside_f' } -- Front doors left and right / if you want all the positions of the vehicle put false
-- Admin Options
Config.CommandGiveKeysEnabled = true                               -- If true command for give key is enabled
Config.CommandGiveKey         = 'givecarkey'                       -- Command Givekey
Config.GroupAllowedCommand    = { 'owner', 'admin' }               -- Group Allowed For Command

Config.EnableMarker = true -- if true enable marker for garage 



-- ░██████╗░░█████╗░██████╗░░█████╗░░██████╗░███████╗
-- ██╔════╝░██╔══██╗██╔══██╗██╔══██╗██╔════╝░██╔════╝
-- ██║░░██╗░███████║██████╔╝███████║██║░░██╗░█████╗░░
-- ██║░░╚██╗██╔══██║██╔══██╗██╔══██║██║░░╚██╗██╔══╝░░
-- ╚██████╔╝██║░░██║██║░░██║██║░░██║╚██████╔╝███████╗
-- ░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝░╚═════╝░╚══════╝

Config.Garage                 = {
    {
        TypeGarage = 'normal',                                         -- normal / boat / aircraft
        IdGarage = 1,                                                  -- Id Garage Important
        PedPosition = vector4(-282.2863, -886.9998, 31.0806, 78.4396), -- Ped Garage Position
        PedModel = 's_m_y_valet_01',                                   -- Ped Model
        PedScenario = 'WORLD_HUMAN_CLIPBOARD',                         -- Ped Scenario
        AllowJob = false,                                              -- Access only for job
        JobName = 'police',                                            -- Name job if Allowjob is True
        SpawnPrewiev = vec4(-282.3838, -900.2645, 30.8105, 19.2548),   -- Spawn Prewiev Cars
        EnablePlayerTeleport = true,                                   -- If true player when open the garage runs a scenario near the vehicle
        PlayerPositionPrewiev = vec3(-285.6139, -899.9008, 30.0806),   -- Spawn Player Position When Open Garage if EnablePlayerTeleport true
        PlayerHeadingPrewiev = 351.3755,                               --Heading Player Position When Open Garage if EnablePlayerTeleport true
        CamMaxHeight = 1.2,                                            -- Height Camera
        CamMaxlength = 4.5,                                            -- Length Camera
        CamMaxFocus = 7.0,                                             -- Focus Camera
        SpawnPosition = {
            vec4(-289.2028, -887.6771, 30.8102, 171.6231),             -- Spawn Position Vehicle
            vec4(-292.9474, -886.8746, 30.8102, 169.7565),
            vec4(-296.8318, -886.3820, 30.8110, 168.2823)
        },
        DepositPosition = vector4(-314.0984, -893.4700, 30.8059, 77.1111), -- Deposit Position / If Config.TargetDepositEnabled = true  use the Range if is false use a marker
        RangeDepositVehicle = 50,                                          -- Range Deposit With Target
        MarkerDeposit = {
            type = 9,
            rot = vector3(0.0, 0.0, 0.0),
            dir = vector3(90.0, 180.0, 0.0),
            scale = vector3(1.3, 1.3, 1.3),
            color = vector4(255, 255, 255, 255),
            bobUpAndDown = false,
            faceCamera = false,
            rotate = true,
            textureDict = 'legacy',
            textureName = 'bg23',
        },
        Blip = {
            BlipSprite = 357,
            BlipDisplay = 2,
            BlipScale = 0.8,
            BlipColor = 3,
            BlipName = "Alta Street",
            EnableBlip = true
        }
    },
    {
        TypeGarage = 'normal',
        IdGarage = 2,
        PedPosition = vector4(44.0346, -844.7084, 30.8487, 166.9401),
        PedModel = 's_m_y_valet_01',
        PedScenario = 'WORLD_HUMAN_CLIPBOARD',
        AllowJob = false,
        JobName = 'police',
        SpawnPrewiev = vec4(37.7596, -852.3532, 30.7180, 73.1990),
        EnablePlayerTeleport = true,
        PlayerPositionPrewiev = vec3(35.2005, -852.0931, 29.7148),
        PlayerHeadingPrewiev = 341.9497,
        CamMaxHeight = 0.8,
        CamMaxlength = 4.0,
        CamMaxFocus = 7.0,
        SpawnPosition = {
            vec4(34.1803, -839.6448, 30.4916, 340.0690),
            vec4(37.4344, -840.7233, 30.6252, 338.8525),
            vec4(40.7790, -841.9587, 30.6136, 339.7972)
        },
        DepositPosition = vector4(56.9743, -848.0993, 30.8269, 256.7780),
        RangeDepositVehicle = 50,
        MarkerDeposit = {
            type = 9,
            rot = vector3(0.0, 0.0, 0.0),
            dir = vector3(90.0, 180.0, 0.0),
            scale = vector3(1.3, 1.3, 1.3),
            color = vector4(255, 255, 255, 255),
            bobUpAndDown = false,
            faceCamera = false,
            rotate = true,
            textureDict = 'legacy',
            textureName = 'bg23',
        },
        Blip = {
            BlipSprite = 357,
            BlipDisplay = 2,
            BlipScale = 0.8,
            BlipColor = 3,
            BlipName = "Power Street",
            EnableBlip = true
        }
    },
    {
        TypeGarage = 'boat',
        IdGarage = 3,
        PedPosition = vector4(-906.7848, -1464.9933, 1.6342, 212.5786),
        PedModel = 'mp_m_boatstaff_01',
        PedScenario = 'WORLD_HUMAN_BINOCULARS',
        AllowJob = true,
        JobName = 'ambulance',
        SpawnPrewiev = vec4(-869.5314, -1454.0266, 0.1196, 237.0420),
        EnablePlayerTeleport = true,
        PlayerPositionPrewiev = vec3(-875.7780, -1464.9448, 0.5954),
        PlayerHeadingPrewiev = 326.9138,
        CamMaxHeight = 2.3,
        CamMaxlength = 6.0,
        CamMaxFocus = 30.0,
        SpawnPosition = {
            vec4(-899.2183, -1452.2450, 0.1113, 326.2864),
        },
        DepositPosition = vector4(-891.2377, -1444.0098, 0.4259, 320.9595),
        RangeDepositVehicle = 50,
        MarkerDeposit = {
            type = 9,
            rot = vector3(0.0, 0.0, 0.0),
            dir = vector3(90.0, 180.0, 0.0),
            scale = vector3(1.3, 1.3, 1.3),
            color = vector4(255, 255, 255, 255),
            bobUpAndDown = false,
            faceCamera = false,
            rotate = true,
            textureDict = 'legacy',
            textureName = 'bg23',
        },
        Blip = {
            BlipSprite = 357,
            BlipDisplay = 2,
            BlipScale = 0.8,
            BlipColor = 3,
            BlipName = "Goma Street",
            EnableBlip = true
        }
    },
    {
        TypeGarage = 'aircraft',
        IdGarage = 4,
        PedPosition = vector4(1755.8921, 3299.6604, 41.1525, 143.4297),
        PedModel = 's_m_y_airworker',
        PedScenario = 'WORLD_HUMAN_BINOCULARS',
        AllowJob = true,
        JobName = 'ambulance',
        SpawnPrewiev = vec4(1749.3646, 3275.9446, 41.1160, 164.0969),
        EnablePlayerTeleport = true,
        PlayerPositionPrewiev = vec3(1755.1229, 3279.9805, 41.0954),
        PlayerHeadingPrewiev = 7.4792,
        CamMaxHeight = 2.3,
        CamMaxlength = 10.0,
        CamMaxFocus = 13.0,
        SpawnPosition = {
            vec4(1710.7333, 3258.7371, 41.0740, 104.3559),
        },
        DepositPosition = vector4(1755.8921, 3299.6604, 41.1525, 143.4297),
        RangeDepositVehicle = 150,
        MarkerDeposit = {
            type = 9,
            rot = vector3(0.0, 0.0, 0.0),
            dir = vector3(90.0, 180.0, 0.0),
            scale = vector3(1.3, 1.3, 1.3),
            color = vector4(255, 255, 255, 255),
            bobUpAndDown = false,
            faceCamera = false,
            rotate = true,
            textureDict = 'legacy',
            textureName = 'bg23',
        },
        Blip = {
            BlipSprite = 357,
            BlipDisplay = 2,
            BlipScale = 0.8,
            BlipColor = 3,
            BlipName = "Panorama Drive",
            EnableBlip = true
        }
    },
    {
        TypeGarage = 'normal',
        IdGarage = 5,
        PedPosition = vector4(1035.1587, -765.5818, 57.9965, 157.1083),
        PedModel = 's_m_y_valet_01',
        PedScenario = 'WORLD_HUMAN_CLIPBOARD',
        AllowJob = true,
        JobName = 'ambulance',
        SpawnPrewiev = vec4(1017.0474, -767.8282, 57.1959, 284.2198),
        EnablePlayerTeleport = true,
        PlayerPositionPrewiev = vec3(1013.2035, -767.4365, 56.8804),
        PlayerHeadingPrewiev = 326.9934,
        CamMaxHeight = 1.3,
        CamMaxlength = 6.0,
        CamMaxFocus = 13.0,
        SpawnPosition = {
            vec4(1020.3463, -776.2951, 57.1831, 132.3408),
            vec4(1018.5831, -773.7985, 57.2008, 128.7676),
            vec4(1022.6989, -779.5928, 57.1715, 130.6603),
        },
        DepositPosition = vector4(1027.6652, -771.9961, 58.0381, 122.2823),
        RangeDepositVehicle = 150,
        MarkerDeposit = {
            type = 9,
            rot = vector3(0.0, 0.0, 0.0),
            dir = vector3(90.0, 180.0, 0.0),
            scale = vector3(1.3, 1.3, 1.3),
            color = vector4(255, 255, 255, 255),
            bobUpAndDown = false,
            faceCamera = false,
            rotate = true,
            textureDict = 'legacy',
            textureName = 'bg23',
        },
        Blip = {
            BlipSprite = 357,
            BlipDisplay = 2,
            BlipScale = 0.8,
            BlipColor = 3,
            BlipName = "West Mirror",
            EnableBlip = true
        }
    }
}

-- ██╗░░██╗███████╗██╗░░░██╗  ░██████╗██╗░░██╗░█████╗░██████╗░
-- ██║░██╔╝██╔════╝╚██╗░██╔╝  ██╔════╝██║░░██║██╔══██╗██╔══██╗
-- █████═╝░█████╗░░░╚████╔╝░  ╚█████╗░███████║██║░░██║██████╔╝
-- ██╔═██╗░██╔══╝░░░░╚██╔╝░░  ░╚═══██╗██╔══██║██║░░██║██╔═══╝░
-- ██║░╚██╗███████╗░░░██║░░░  ██████╔╝██║░░██║╚█████╔╝██║░░░░░
-- ╚═╝░░╚═╝╚══════╝░░░╚═╝░░░  ╚═════╝░╚═╝░░╚═╝░╚════╝░╚═╝░░░░░

Config.RecoveryKeys = {
    {
        PedPos = vec4(-56.087562561035, -1098.4111328125, 25.931186676025, 341.8551),
        PedScenario = 'PROP_HUMAN_SEAT_COMPUTER',
        PedModel = 'a_f_y_business_01',

        Blip = {
            BlipSprite = 357,
            BlipDisplay = 2,
            BlipScale = 0.8,
            BlipColor = 3,
            BlipName = "Recupera Chiavi",
            EnableBlip = true
        }
    }
}



-- ░░░░░██╗░█████╗░██████╗░  ░██████╗░░█████╗░██████╗░░█████╗░░██████╗░███████╗
-- ░░░░░██║██╔══██╗██╔══██╗  ██╔════╝░██╔══██╗██╔══██╗██╔══██╗██╔════╝░██╔════╝
-- ░░░░░██║██║░░██║██████╦╝  ██║░░██╗░███████║██████╔╝███████║██║░░██╗░█████╗░░
-- ██╗░░██║██║░░██║██╔══██╗  ██║░░╚██╗██╔══██║██╔══██╗██╔══██║██║░░╚██╗██╔══╝░░
-- ╚█████╔╝╚█████╔╝██████╦╝  ╚██████╔╝██║░░██║██║░░██║██║░░██║╚██████╔╝███████╗
-- ░╚════╝░░╚════╝░╚═════╝░  ░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝░╚═════╝░╚══════╝

Config.UseOxFuel = false -- If true set 100 fuel whit ox if false use ESX function

Config.JobGarage = {
    {
        idGarage = 1,
        GaragePedPos = vec4(-867.0375, -1514.2682, 5.1728, 13.3910),
        GaragePedScenario = 'WORLD_HUMAN_CLIPBOARD',
        GaragePedModel = 'a_f_y_business_01',
        GarageJobName = 'police',
        Vehicles = {
            { label = 'Kuruma',  nameSpawn = 'kuruma', },
            { label = 'T20',     nameSpawn = 't20', }
        },
        SpawnPosition = vec4(-856.1517, -1509.4561, 4.9226, 23.5215),
        DepositPosition = vec3(-901.4283, -1528.4987, 4.7529),
        Blip = {
            BlipSprite = 357,
            BlipDisplay = 2,
            BlipScale = 0.8,
            BlipColor = 3,
            BlipName = "Private Garage Police",
            EnableBlip = false
        },
        MarkerDepositJob = {
            type = 9,
            rot = vector3(0.0, 0.0, 0.0),
            dir = vector3(90.0, 180.0, 0.0),
            scale = vector3(1.3, 1.3, 1.3),
            color = vector4(255, 255, 255, 255),
            bobUpAndDown = false,
            faceCamera = false,
            rotate = true,
            textureDict = 'legacy',
            textureName = 'bg23',
        },
    },
    {
        idGarage = 2,
        GaragePedPos = vec4(-865.4824, -1511.8414, 5.1794, 301.7172),
        GaragePedScenario = 'WORLD_HUMAN_CLIPBOARD',
        GaragePedModel = 'a_f_y_business_01',

        GarageJobName = 'ambulance',
        Vehicles = {
            { label = 'Kuruma', nameSpawn = 'kuruma', },
        },
        SpawnPosition = vec4(-856.1517, -1509.4561, 4.9226, 23.5215),
        DepositPosition = vec3(-866.5245, -1506.9553, 5.1708),
        Blip = {
            BlipSprite = 357,
            BlipDisplay = 2,
            BlipScale = 0.8,
            BlipColor = 3,
            BlipName = "Private Garage Ambulance",
            EnableBlip = true
        },
        MarkerDepositJob = {
            type = 9,
            rot = vector3(0.0, 0.0, 0.0),
            dir = vector3(90.0, 180.0, 0.0),
            scale = vector3(1.3, 1.3, 1.3),
            color = vector4(255, 255, 255, 255),
            bobUpAndDown = false,
            faceCamera = false,
            rotate = true,
            textureDict = 'legacy',
            textureName = 'bg23',
        },
    }
}

