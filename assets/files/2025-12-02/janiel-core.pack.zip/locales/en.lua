local res = GetCurrentResourceName()
janiel.i18n.register(res, 'en', {
  no_permission = 'No permission',
  menu_actions = 'Actions',
  hint_press_e = 'Press E to interact',
  progress_processing = 'Processing...',
})
