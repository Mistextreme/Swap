(function(){
  const root = document.getElementById('notify-root');
  const progressRoot = document.getElementById('progress-root');
  const hintRoot = document.getElementById('hint-root');
  const menuRoot = document.getElementById('menu-root');
  let maxStack = 4;
  let position = 'top-right';
  let useFA = false;
  let progressTimer = null;
  const resource = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'janiel-core';

  function setPosition(pos){
    root.classList.remove('pos-top-right','pos-top-left','pos-bottom-right','pos-bottom-left');
    const map = {
      'top-right': 'pos-top-right',
      'top-left': 'pos-top-left',
      'bottom-right': 'pos-bottom-right',
      'bottom-left': 'pos-bottom-left'
    };
    root.classList.add(map[pos] || 'pos-top-right');
  }

  function clampStack(){
    while(root.children.length > maxStack){
      root.removeChild(root.firstElementChild);
    }
  }

  function iconClass(type){
    switch(type){
      case 'success': return 'fa-solid fa-circle-check';
      case 'info': return 'fa-solid fa-circle-info';
      case 'warning': return 'fa-solid fa-triangle-exclamation';
      case 'error': return 'fa-solid fa-circle-xmark';
      default: return 'fa-solid fa-bell';
    }
  }

  function createToast({message, type='primary', title='', duration=3500}){
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `
      ${useFA ? `<i class=\"icon ${iconClass(type)}\"></i>` : '<span class="dot"></span>'}
      <div class="content">
        ${title ? `<div class=\"title\">${title}</div>` : ''}
        <div class="message"></div>
      </div>
      <button class="close" aria-label="Close">×</button>
      <div class="bar"></div>
    `;
    el.querySelector('.message').textContent = message;

    const close = () => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 200);
    };

    el.querySelector('.close').addEventListener('click', close);

    root.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));

    clampStack();

    if(duration > 0){
      const bar = el.querySelector('.bar');
      if(bar){
        bar.style.animationDuration = `${duration}ms`;
      }
      setTimeout(close, duration);
    }
  }

  window.addEventListener('message', (event) => {
    const data = event.data || {};
    if(data.action === 'notify'){
      const cfg = data.config || {};
      if(cfg.position && cfg.position !== position){
        position = cfg.position;
        setPosition(position);
      }
      if(typeof cfg.maxStack === 'number'){
        maxStack = cfg.maxStack;
      }
      if(typeof cfg.useFA === 'boolean'){
        useFA = cfg.useFA;
      }
      createToast({
        message: data.message,
        type: data.type || 'primary',
        title: data.title || '',
        duration: typeof cfg.duration === 'number' ? cfg.duration : 3500
      });
    } else if (data.action === 'progress_start') {
      progressRoot.innerHTML = `
        <div class="progress-wrap">
          <div class="progress-label"></div>
          <div class="progress-bar"><span></span></div>
        </div>`;
      const labelEl = progressRoot.querySelector('.progress-label');
      const barFill = progressRoot.querySelector('.progress-bar > span');
      labelEl.textContent = data.label || '';
      progressRoot.style.display = 'block';
      const total = Math.max(0, Number(data.duration || 0));
      const start = performance.now();
      if (progressTimer) cancelAnimationFrame(progressTimer);
      const step = (now) => {
        const elapsed = now - start;
        const pct = Math.min(100, (elapsed / total) * 100);
        barFill.style.width = `${pct}%`;
        if (elapsed < total) {
          progressTimer = requestAnimationFrame(step);
        }
      };
      progressTimer = requestAnimationFrame(step);
    } else if (data.action === 'progress_stop') {
      if (progressTimer) cancelAnimationFrame(progressTimer);
      progressTimer = null;
      progressRoot.style.display = 'none';
      progressRoot.innerHTML = '';
    } else if (data.action === 'hint_show') {
      hintRoot.innerHTML = `<div class="hint-wrap">${data.text || ''}</div>`;
      hintRoot.style.display = 'block';
    } else if (data.action === 'hint_hide') {
      hintRoot.style.display = 'none';
      hintRoot.innerHTML = '';
    } else if (data.action === 'menu_open') {
      const title = data.title || 'Menu';
      const items = Array.isArray(data.items) ? data.items : [];
      useFA = true;
      
      menuRoot.innerHTML = `
        <div class="menu-backdrop" data-close></div>
        <div class="menu-wrap">
          <div class="menu-header">${title}</div>
          <div class="menu-list"></div>
          <div class="menu-footer">
            <button class="menu-close">Close</button>
          </div>
        </div>`;
      menuRoot.style.display = 'flex';
      const wrap = menuRoot.querySelector('.menu-wrap');
      requestAnimationFrame(() => wrap.classList.add('show'));
      const list = menuRoot.querySelector('.menu-list');
      items.forEach((it, idx) => {
        const row = document.createElement('div');
        row.className = 'menu-item';
        row.innerHTML = `
          ${useFA && it.icon ? `<i class="icon ${it.icon}"></i>` : '<span class="icon"></span>'}
          <div class="content">
            <div class="label"></div>
            ${it.description ? `<div class="description"></div>` : ''}
          </div>`;
        row.querySelector('.label').textContent = it.label || `Item ${idx+1}`;
        if (it.description) {
          row.querySelector('.description').textContent = it.description;
        }
        row.addEventListener('click', () => {
          fetch(`https://${resource}/menu_select`, { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: it.id ?? idx, item: it }) });
        });
        list.appendChild(row);
      });
      const doClose = () => {
        fetch(`https://${resource}/menu_close`, { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({}) });
      };
      menuRoot.querySelector('.menu-close').addEventListener('click', doClose);
      menuRoot.querySelector('.menu-backdrop').addEventListener('click', doClose);
      const onKey = (e) => { if (e.key === 'Escape') { doClose(); } };
      window.addEventListener('keydown', onKey, { once: true });
    } else if (data.action === 'menu_close') {
      const wrap = menuRoot.querySelector('.menu-wrap');
      if (wrap) wrap.classList.remove('show');
      setTimeout(() => { menuRoot.style.display = 'none'; menuRoot.innerHTML = ''; }, 150);
    } else if(data.action === 'setup'){
      const cfg = data.config || {};
      position = cfg.position || position;
      maxStack = typeof cfg.maxStack === 'number' ? cfg.maxStack : maxStack;
      useFA = !!cfg.useFA;
      setPosition(position);
      try { console.log('[janiel-ui] setup', cfg); } catch(e) {}
    }
  });

  setPosition(position);
})();
