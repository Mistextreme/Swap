-- Test commands for janiel-core modules


janiel.cmd.register('test_notify', function(src, args)
    local typ = tostring(args[1] or 'info')
    local title = args[2] and table.concat(args, ' ', 2) or 'Notify Test'
    janiel.notify.send(src, ('Hello from %s'):format(GetCurrentResourceName()), typ)
end, { permission = 'any' })

janiel.cmd.register('test_menu', function(src)
    local items = {
        { id = 'use', label = 'Use Item', icon = 'fa-solid fa-hand' },
        { id = 'give', label = 'Give Item', icon = 'fa-solid fa-gift' },
        { id = 'drop', label = 'Drop Item', icon = 'fa-solid fa-trash' },
    }
    TriggerClientEvent('janiel.ui:menu', src, { title = 'Actions', items = items })
end, { permission = 'any' })

RegisterNetEvent('janiel.ui:menu:selected', function(choice, data)
    local src = source
    local id = choice or (data and data.id)
    janiel.notify.send(src, ('Menu selected: %s'):format(tostring(id)), 'info')
end)

-- progress & hint/target
janiel.cmd.register('test_progress', function(src, args)
    local ms = tonumber(args[1] or 3000) or 3000
    TriggerClientEvent('janiel.ui:progress', src, 'Processing...', ms)
end, { permission = 'any' })

janiel.cmd.register('test_hint', function(src, args)
    local text = table.concat(args, ' ') ~= '' and table.concat(args, ' ') or 'Press E to interact'
    TriggerClientEvent('janiel.ui:hint', src, text, 3000)
end, { permission = 'any' })

janiel.cmd.register('test_target_show', function(src, args)
    local x = tonumber(args[1] or nil)
    local y = tonumber(args[2] or nil)
    local z = tonumber(args[3] or nil)
    local label
    if x and y and z then
        label = (args[4] and table.concat(args, ' ', 4))
    else
        -- fallback to player coords; whole args make up label
        local ped = GetPlayerPed(src)
        local px, py, pz = table.unpack(GetEntityCoords(ped))
        x, y, z = px, py, pz
        label = (#args > 0 and table.concat(args, ' ') or nil)
    end
    label = (label and label ~= '' and label) or 'Stand here'
    TriggerClientEvent('janiel.target:add', src, {
        coords = { x = x, y = y, z = z },
        label = label,
        distance = 2.0,
        _storeAsLast = true,
    })
end, { permission = 'any' })

janiel.cmd.register('test_target_hide', function(src)
    TriggerClientEvent('janiel.target:remove', src)
end, { permission = 'any' })

-- npc spawn
janiel.cmd.register('test_npc', function(src, args)
    local model = args[1] or 'a_m_m_business_01'
    local heading = tonumber(args[2] or 0.0) or 0.0
    local ped = GetPlayerPed(src)
    local x, y, z = table.unpack(GetEntityCoords(ped))
    TriggerClientEvent('janiel.npc:spawn', src, {
        model = model,
        heading = heading,
        coords = { x = x, y = y, z = z },
        invincible = true,
        freeze = true,
    })
end, { permission = 'any' })

-- inventory add/remove/has/count
janiel.cmd.register('test_inv_add', function(src, args)
    local item = tostring(args[1] or 'water')
    local count = tonumber(args[2] or 1) or 1
    local ok = janiel.inv.add(src, item, count)
    janiel.notify.send(src, (ok and 'Added' or 'Failed to add')..' '..item, ok and 'success' or 'error')
end, { permission = 'any' })

janiel.cmd.register('test_inv_has', function(src, args)
    local item = tostring(args[1] or 'water')
    local count = tonumber(args[2] or 1) or 1
    local ok = janiel.inv.has(src, item, count)
    janiel.notify.send(src, (ok and 'Has ' or 'Missing ')..item..' x'..count, ok and 'success' or 'warning')
end, { permission = 'any' })

janiel.cmd.register('test_inv_count', function(src, args)
    local item = tostring(args[1] or 'water')
    local n = janiel.inv.count(src, item)
    janiel.notify.send(src, ('%s count: %d'):format(item, n), 'info')
end, { permission = 'any' })

-- logging
janiel.cmd.register('test_log', function(src)
    janiel.log.trace('trace log')
    janiel.log.debug('debug log')
    janiel.log.info('info log')
    janiel.log.warn('warn log')
    janiel.log.error('error log')
    janiel.notify.send(src, 'Logs printed to console', 'primary')
end, { permission = 'any' })

-- callbacks
janiel.cmd.register('test_cb', function(src)
    -- client -> server
    TriggerClientEvent('chat:addMessage', src, {args={'^3janiel-core', 'Triggering client->server cb...'}})
    -- server registers getData already, so trigger from client is separate.
    -- here we do server->client and await response
    janiel.cb.triggerClient(src, 'ping', {}, function(result)
        if result then
            janiel.notify.send(src, 'Server->Client cb: '..tostring(result), 'success')
        else
            janiel.notify.send(src, 'Server->Client cb timeout', 'error')
        end
    end)
end, { permission = 'any' })

-- player utils
janiel.cmd.register('test_player', function(src)
    local job = janiel.player.getJob(src)
    local gang = janiel.player.getGang(src)
    janiel.notify.send(src, ('Job: %s (%s) | Gang: %s'):format(job.name or 'n/a', tostring(job.grade or 0), gang.name or 'none'), 'info')
end, { permission = 'any' })

-- state & time
janiel.cmd.register('test_state', function(src)
    janiel.state.setGlobal('janiel:test', (janiel.state.getGlobal('janiel:test') or 0) + 1)
    local v = janiel.state.getGlobal('janiel:test')
    janiel.notify.send(src, 'Global state janiel:test = '..tostring(v), 'primary')
end, { permission = 'any' })

janiel.cmd.register('test_time', function(src)
    janiel.notify.send(src, 'Timeout in 2s...', 'warning')
    janiel.time.setTimeout(function()
        janiel.notify.send(src, 'Timeout done', 'success')
    end, 2000)
end, { permission = 'any' })
