janiel = janiel or {}
janiel.keybind = janiel.keybind or {}

local mappings = {}

function janiel.keybind.register(name, default, description, onPressed)
    if mappings[name] then return end
    RegisterKeyMapping(('janiel-%s'):format(name), description or ('Janiel %s'):format(name), 'keyboard', default or 'F9')
    RegisterCommand(('janiel.%s'):format(name), function()
        if onPressed then pcall(onPressed) end
    end, false)
    mappings[name] = true
end
