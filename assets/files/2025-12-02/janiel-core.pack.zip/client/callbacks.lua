janiel = janiel or {}
janiel.cb = janiel.cb or {}

local cliHandlers = {}
local pending = {}
local reqId = 0

local function nextId()
    reqId = reqId + 1
    return tostring(reqId)
end

function janiel.cb.register(name, fn)
    cliHandlers[name] = fn
end

RegisterNetEvent('janiel.cb:req:client', function(name, id, payload)
    local h = cliHandlers[name]
    local ok, res
    if h then
        ok, res = pcall(h, payload)
    else
        ok, res = false, nil
    end
    TriggerServerEvent('janiel.cb:res:server', id, ok and res or nil)
end)

function janiel.cb.trigger(name, payload, cb)
    local id = nextId()
    if cb then
        pending[id] = cb
        SetTimeout(10000, function()
            if pending[id] then pending[id](nil); pending[id] = nil end
        end)
    end
    TriggerServerEvent('janiel.cb:req:server', name, id, payload)
end

RegisterNetEvent('janiel.cb:res:client', function(id, result)
    local cb = pending[id]
    if cb then
        pending[id] = nil
        cb(result)
    end
end)

janiel.cb.register('ping', function(payload)
    return 'pong'
end)
