janiel = janiel or {}

local function detectFramework()
    if GetResourceState('es_extended') == 'started' then
        return 'esx'
    elseif GetResourceState('qb-core') == 'started' then
        return 'qb'
    elseif GetResourceState('qbx_core') == 'started' then
        return 'qbx'
    end
    return 'none'
end

local function detectTargetProvider()
    local cfg = Config and Config.Target and Config.Target.Provider or 'auto'
    if cfg ~= 'auto' then
        if cfg == 'ox' and GetResourceState('ox_target') == 'started' then return 'ox' end
        if cfg == 'qb' and GetResourceState('qb-target') == 'started' then return 'qb' end
        return 'none'
    end
    if GetResourceState('ox_target') == 'started' then return 'ox' end
    if GetResourceState('qb-target') == 'started' then return 'qb' end
    return 'none'
end

janiel.framework = detectFramework()
janiel.targetProvider = detectTargetProvider()

print("^2[janiel-core] Framework detected: " .. string.upper(janiel.framework) .. "^0")
print("^2[janiel-core] Target provider: " .. string.upper(janiel.targetProvider) .. "^0")

janiel.target = {
    add = function(data) end,
    remove = function(id) end,
    clear = function() end
}

janiel.interact = {
    add = function(opts) end,
    remove = function(id) end
}

janiel.ui = {
    menuOpen = function(opts, cb) end,
    menuClose = function() end
}

janiel.npc = {
    spawn = function(opts) end
}

janiel.ready = true
