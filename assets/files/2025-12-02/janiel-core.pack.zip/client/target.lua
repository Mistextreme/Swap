janiel = janiel or {}
janiel.target = janiel.target or {}

local provider = (janiel and janiel.targetProvider) or 'none'

CreateThread(function()
    while not (janiel and janiel.targetProvider) do
        Wait(100)
    end
    provider = janiel.targetProvider
end)
local targets = {}
local lastId = nil
local nextId = 0
local nearbyTargets = {}
local isNearTarget = false
local currentTarget = nil

local function genId()
    nextId = nextId + 1
    return nextId
end

local function toVec3(c)
    if type(c) == 'vector3' then return c end
    return vector3(c.x, c.y, c.z)
end

local function toOptions(opts)
    local out = {}
    for i, o in ipairs(opts or {}) do
        out[#out+1] = {
            label = o.label or ('Option '..i),
            icon = o.icon,
            action = o.action or function()
                if o.event then
                    TriggerEvent(o.event, o.args)
                elseif o.serverEvent then
                    TriggerServerEvent(o.serverEvent, o.args)
                end
            end,
            onSelect = function()
                if o.action then
                    pcall(o.action, o.args)
                elseif o.event then
                    TriggerEvent(o.event, o.args)
                elseif o.serverEvent then
                    TriggerServerEvent(o.serverEvent, o.args)
                end
            end
        }
    end
    return out
end

function janiel.target.add(data)
    data = data or {}
    local id = genId()
    local label = data.label or 'Interact'
    local distance = tonumber(data.distance or 2.0) or 2.0
    local pid

    if provider == 'ox' then
        if data.entity and DoesEntityExist(data.entity) then
            pid = exports.ox_target:addLocalEntity(data.entity, toOptions(data.options))
        elseif data.coords then
            pid = exports.ox_target:addSphereZone({ name = 'janiel_'..id, coords = toVec3(data.coords), radius = distance, debug = false, options = toOptions(data.options) })
        end
    elseif provider == 'qb' then
        if data.entity and DoesEntityExist(data.entity) then
            exports['qb-target']:AddTargetEntity(data.entity, { options = toOptions(data.options), distance = distance })
            pid = data.entity
        elseif data.coords then
            local name = 'janiel_'..id
            exports['qb-target']:AddCircleZone(name, toVec3(data.coords), distance, { useZ = true }, { options = toOptions(data.options), distance = distance })
            pid = name
        end
    else
        nearbyTargets[id] = {
            coords = toVec3(data.coords),
            label = label,
            distance = distance,
            options = data.options or {}
        }
        pid = id
    end

    targets[id] = { provider = provider, pid = pid, label = label, entity = data.entity, coords = data.coords, options = data.options or {} }
    return id
end

function janiel.target.remove(id)
    local t = targets[id]
    if not t then return end
    if t.provider == 'ox' then
        if t.pid then exports.ox_target:removeZone(t.pid) end
        if t.entity then exports.ox_target:removeLocalEntity(t.entity) end
    elseif t.provider == 'qb' then
        if type(t.pid) == 'string' then
            exports['qb-target']:RemoveZone(t.pid)
        elseif t.entity then
            exports['qb-target']:RemoveTargetEntity(t.entity)
        end
    else
        nearbyTargets[id] = nil
        if currentTarget == id then
            currentTarget = nil
            isNearTarget = false
        end
    end
    targets[id] = nil
end

function janiel.target.clear()
    for id, _ in pairs(targets) do
        janiel.target.remove(id)
    end
end

RegisterNetEvent('janiel.target:add', function(data)
    if data and data._storeAsLast and lastId then
        janiel.target.remove(lastId)
        lastId = nil
    end
    local id = janiel.target.add(data)
    if data and data._storeAsLast then lastId = id end
end)

RegisterNetEvent('janiel.target:remove', function(id)
    id = id or lastId
    if id then
        janiel.target.remove(id)
        if lastId == id then lastId = nil end
    end
end)

local function FixTurkishChars(text)
    return text:gsub("ı", "i"):gsub("İ", "I"):gsub("ş", "s"):gsub("Ş", "S"):gsub("ğ", "g"):gsub("Ğ", "G"):gsub("ü", "u"):gsub("Ü", "U"):gsub("ö", "o"):gsub("Ö", "O"):gsub("ç", "c"):gsub("Ç", "C")
end

local function DrawText3D(coords, text)
    local onScreen, _x, _y = World3dToScreen2d(coords.x, coords.y, coords.z + 0.5)
    if not onScreen then return end
    local fixedText = FixTurkishChars(text)
    
    local scale = 0.35
    SetTextScale(scale, scale)
    SetTextFont(4)
    SetTextEntry("STRING")
    SetTextCentre(1)
    SetTextColour(255, 255, 255, 215)
    AddTextComponentString(fixedText)
    DrawText(_x, _y)
    
    local factor = (string.len(fixedText)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 41, 41, 41, 68)
end

local function CheckNearbyTargets()
    if provider ~= 'none' then return end
    
    local playerCoords = GetEntityCoords(PlayerPedId())
    local closestTarget = nil
    local closestDistance = 999.0
    
    for id, target in pairs(nearbyTargets) do
        local distance = #(playerCoords - target.coords)
        if distance <= target.distance and distance < closestDistance then
            closestTarget = id
            closestDistance = distance
        end
    end
    
    if closestTarget ~= currentTarget then
        currentTarget = closestTarget
        isNearTarget = closestTarget ~= nil
    end
    
    if isNearTarget and currentTarget then
        local target = nearbyTargets[currentTarget]
        DrawText3D(target.coords, "[E] " .. target.label)
        
        if IsControlJustReleased(0, 38) then
            if #target.options > 0 then
                if #target.options == 1 then
                    local option = target.options[1]
                    if option.action then
                        option.action()
                    elseif option.event then
                        TriggerEvent(option.event, option.args)
                    elseif option.serverEvent then
                        TriggerServerEvent(option.serverEvent, option.args)
                    end
                else
                    local option = target.options[1] 
                    if option.action then
                        option.action()
                    elseif option.event then
                        TriggerEvent(option.event, option.args)
                    elseif option.serverEvent then
                        TriggerServerEvent(option.serverEvent, option.args)
                    end
                end
            end
        end
    end
end

CreateThread(function()
    while true do
        Wait(0)
        CheckNearbyTargets()
    end
end)
