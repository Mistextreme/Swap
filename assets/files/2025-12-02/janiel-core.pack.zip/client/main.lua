janiel = janiel or {}

local function setupNui()
    if Config and Config.Notify then
        SendNUIMessage({
            action = 'setup',
            config = {
                position = Config.Notify.Position,
                duration = Config.Notify.Duration,
                maxStack = Config.Notify.MaxStack,
                useFA = Config.Notify.UseFA
            }
        })
    end
end

AddEventHandler('onClientResourceStart', function(res)
    if res == GetCurrentResourceName() then
        setupNui()
    end
end)

RegisterNetEvent('janiel.anur:notify', function(message, ntype, title)
    SendNUIMessage({
        action = 'notify',
        message = tostring(message or ''),
        type = tostring(ntype or 'primary'),
        title = title or '',
        config = {
            position = Config.Notify.Position,
            duration = Config.Notify.Duration,
            maxStack = Config.Notify.MaxStack,
            useFA = Config.Notify.UseFA
        }
    })
end)
