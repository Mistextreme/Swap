janiel = janiel or {}
janiel.npc = janiel.npc or {}

local spawnedNpcs = {}

local function loadModel(model)
    if type(model) == 'string' then model = joaat(model) end
    if not IsModelInCdimage(model) then return false end
    RequestModel(model)
    local timeout = 5000
    while not HasModelLoaded(model) and timeout > 0 do
        Wait(10)
        timeout = timeout - 10
    end
    return HasModelLoaded(model)
end

function janiel.npc.spawn(opts)
    opts = opts or {}
    local model = opts.model or 'a_m_m_business_01'
    local heading = opts.heading or 0.0
    local coords = opts.coords or GetEntityCoords(PlayerPedId())
    if type(coords) ~= 'vector3' then coords = vector3(coords.x, coords.y, coords.z) end

    if not loadModel(model) then
        return nil
    end

    local ped = CreatePed(4, type(model) == 'number' and model or joaat(model), coords.x, coords.y, coords.z, heading + 0.0, false, true)
    if ped and ped ~= 0 then
        SetEntityAsMissionEntity(ped, true, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        SetEntityInvincible(ped, opts.invincible ~= false)
        FreezeEntityPosition(ped, opts.freeze ~= false)
        SetPedFleeAttributes(ped, 0, false)
        SetPedCombatAttributes(ped, 46, true)
        spawnedNpcs[#spawnedNpcs + 1] = ped
        return ped
    end
    return nil
end

function janiel.npc.cleanup()
    for _, ped in ipairs(spawnedNpcs) do
        if DoesEntityExist(ped) then
            DeleteEntity(ped)
        end
    end
    spawnedNpcs = {}
end

RegisterNetEvent('janiel.npc:spawn', function(data)
    janiel.npc.spawn(data)
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then
        janiel.npc.cleanup()
    end
end)
