janiel = janiel or {}
janiel.interact = janiel.interact or {}

local interactions = {}
local nextId = 0
local currentId = nil
local currentOpt = 1
local enabled = true

local function genId()
    nextId = nextId + 1
    return nextId
end

local function dist(a, b)
    local dx = a.x - b.x
    local dy = a.y - b.y
    local dz = a.z - b.z
    return math.sqrt(dx*dx + dy*dy + dz*dz)
end

local function getCoordsFromInteract(i)
    if i.entity and DoesEntityExist(i.entity) then
        local c = GetEntityCoords(i.entity)
        return vector3(c.x, c.y, c.z)
    end
    return i.coords
end

function janiel.interact.add(opts)
    local id = genId()
    interactions[id] = {
        id = id,
        entity = opts.entity,
        coords = opts.coords and vector3(opts.coords.x, opts.coords.y, opts.coords.z) or nil,
        label = opts.label or 'Interact',
        options = opts.options or {},
        distance = tonumber(opts.distance or 2.0) or 2.0,
    }
    return id
end

function janiel.interact.remove(id)
    if interactions[id] then
        interactions[id] = nil
        if currentId == id then
            currentId = nil
            currentOpt = 1
            if janiel.ui and janiel.ui.hintHide then janiel.ui.hintHide() end
        end
    end
end

function janiel.interact.clear()
    interactions = {}
    currentId = nil
    currentOpt = 1
    if janiel.ui and janiel.ui.hintHide then janiel.ui.hintHide() end
end

local function hasLineOfSight(from, to)
    local handle = StartShapeTestRay(from.x, from.y, from.z + 0.98, to.x, to.y, to.z + 0.5, -1, PlayerPedId(), 7)
    local _, hit, _, _, _ = GetShapeTestResult(handle)
    return hit == 0
end

CreateThread(function()
    local losTick = 0
    local interval = GetConvarInt('janiel_interact_thread', 200)
    while true do
        local wait = interval
        if enabled and next(interactions) ~= nil then
            if IsNuiFocused() or IsPauseMenuActive() or IsPedDeadOrDying(PlayerPedId()) then
                if currentId ~= nil and janiel.ui and janiel.ui.hintHide then janiel.ui.hintHide() end
                currentId, currentOpt = nil, 1
                Wait(wait)
            else
                local ped = PlayerPedId()
                local pcoords = GetEntityCoords(ped)
                local bestId, bestDist
                losTick = (losTick + 1) % 5
                for id, i in pairs(interactions) do
                    local ic = getCoordsFromInteract(i)
                    if ic then
                        local d = dist(vector3(pcoords.x, pcoords.y, pcoords.z), ic)
                        if d <= i.distance then
                            if not bestDist or d < bestDist then
                                local pass = true
                                if losTick == 0 then
                                    pass = hasLineOfSight(vector3(pcoords.x, pcoords.y, pcoords.z), ic)
                                end
                                if pass then
                                    bestId, bestDist = id, d
                                end
                            end
                        end
                    end
                end

                if bestId then
                    wait = math.min(50, interval)
                    if currentId ~= bestId then
                        currentId = bestId
                        currentOpt = 1
                    end
                    local entry = interactions[currentId]
                    local opts = entry.options
                    local label = entry.label
                    if #opts > 0 then
                        label = (opts[currentOpt] and opts[currentOpt].label) and (opts[currentOpt].label) or label
                    end
                    if janiel.ui and janiel.ui.hintShow then
                        janiel.ui.hintShow(('E - %s'):format(label))
                    end

                    if IsControlJustPressed(0, 172) or IsControlJustPressed(0, 15) then
                        if #opts > 1 then
                            currentOpt = math.max(1, currentOpt - 1)
                        end
                    elseif IsControlJustPressed(0, 173) or IsControlJustPressed(0, 14) then
                        if #opts > 1 then
                            currentOpt = math.min(#opts, currentOpt + 1)
                        end
                    elseif IsControlJustPressed(0, 38) then
                        if #opts > 0 and opts[currentOpt] then
                            local o = opts[currentOpt]
                            if o.action then
                                pcall(o.action, entry.entity, entry.coords, o.args)
                            elseif o.event then
                                TriggerEvent(o.event, o.args)
                            elseif o.serverEvent then
                                TriggerServerEvent(o.serverEvent, o.args)
                            end
                        else
                            TriggerEvent('janiel.interact:interact', entry.label)
                        end
                    end
                else
                    if currentId ~= nil then
                        currentId = nil
                        currentOpt = 1
                        if janiel.ui and janiel.ui.hintHide then janiel.ui.hintHide() end
                    end
                end
            end
        end
        Wait(wait)
    end
end)


local ephemeralId = nil
RegisterNetEvent('janiel.interact:show', function(text)
    if ephemeralId then janiel.interact.remove(ephemeralId) end
    ephemeralId = janiel.interact.add({ coords = GetEntityCoords(PlayerPedId()), label = text or 'Interact', options = {}, distance = 2.0 })
end)
RegisterNetEvent('janiel.interact:hide', function()
    if ephemeralId then janiel.interact.remove(ephemeralId) end
    ephemeralId = nil
end)


if janiel and janiel.keybind and janiel.keybind.register then
    janiel.keybind.register('interact', 'E', 'Janiel Interact', function()
    end)
end
