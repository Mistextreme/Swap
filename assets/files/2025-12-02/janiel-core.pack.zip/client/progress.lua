janiel = janiel or {}
janiel.ui = janiel.ui or {}

local current = nil

function janiel.ui.progressStart(label, duration)
    if current then return false end
    duration = duration or 3000
    current = true
    SendNUIMessage({ action = 'progress_start', label = tostring(label or ''), duration = duration })
    CreateThread(function()
        Wait(duration)
        if current then
            janiel.ui.progressStop()
        end
    end)
    return true
end

function janiel.ui.progressStop()
    if not current then return end
    current = nil
    SendNUIMessage({ action = 'progress_stop' })
    ClearPedTasks(PlayerPedId())
end

RegisterNetEvent('janiel.ui:progress', function(label, duration)
    janiel.ui.progressStart(label, duration)
end)

exports('janiel_progress', function(data, cb)
    if not data or not data.duration then return end
    local animDict, animFlag = nil, nil
    if data.animation then
        animDict = data.animation.dict
        animFlag = data.animation.flag or 49
        if animDict then
            RequestAnimDict(animDict)
            while not HasAnimDictLoaded(animDict) do
                Wait(10)
            end
            TaskPlayAnim(PlayerPedId(), animDict, data.animation.clip, 8.0, -8.0, -1, animFlag, 0, false, false, false)
        end
    end
    if data.controlDisables then
        if data.controlDisables.disableMovement then
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
        end
        if data.controlDisables.disableCarMovement then
            DisableControlAction(0, 71, true)
            DisableControlAction(0, 72, true)
        end
        if data.controlDisables.disableCombat then
            DisableControlAction(0, 140, true)
            DisableControlAction(0, 141, true)
        end
    end
    
    local success = janiel.ui.progressStart(data.label, data.duration)
    if success then
        CreateThread(function()
            while current do
                if data.controlDisables then
                    if data.controlDisables.disableMovement then
                        DisableControlAction(0, 24, true)
                        DisableControlAction(0, 25, true)
                    end
                    if data.controlDisables.disableCarMovement then
                        DisableControlAction(0, 71, true)
                        DisableControlAction(0, 72, true)
                    end
                    if data.controlDisables.disableCombat then
                        DisableControlAction(0, 140, true)
                        DisableControlAction(0, 141, true)
                    end
                end
                Wait(0)
            end
            ClearPedTasks(PlayerPedId())
            ClearPedSecondaryTask(PlayerPedId())
            
            if cb then cb(false) end
        end)
    else
        ClearPedTasks(PlayerPedId())
        ClearPedSecondaryTask(PlayerPedId())
        if cb then cb(true) end
    end
end)
