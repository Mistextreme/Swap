janiel = janiel or {}
janiel.ui = janiel.ui or {}

local hintActive = false
local hideTimer = nil

local function clearHideTimer()
    if hideTimer then
        if type(hideTimer) == 'number' then
        end
        hideTimer = nil
    end
end

function janiel.ui.hintShow(text)
    hintActive = true
    SendNUIMessage({ action = 'hint_show', text = tostring(text or '') })
end

function janiel.ui.hintHide()
    hintActive = false
    SendNUIMessage({ action = 'hint_hide' })
end


RegisterNetEvent('janiel.ui:hint', function(text, duration)
    duration = tonumber(duration or 0) or 0
    clearHideTimer()
    if duration == 1 then
        janiel.ui.hintHide()
        return
    end
    janiel.ui.hintShow(text)
    if duration > 0 then
        hideTimer = duration
        CreateThread(function()
            Wait(duration)
            if hintActive then
                janiel.ui.hintHide()
            end
        end)
    end
end)
