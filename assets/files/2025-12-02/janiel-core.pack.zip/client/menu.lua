janiel = janiel or {}
janiel.ui = janiel.ui or {}

local _menuOpen = false
local _menuCb = nil

local function closeMenu()
    SetNuiFocus(false, false)
    _menuOpen = false
    _menuCb = nil
    SendNUIMessage({ action = 'menu_close' })
end

function janiel.ui.menuOpen(opts, cb)
    if _menuOpen then return false end
    _menuOpen = true
    _menuCb = cb
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'menu_open',
        title = (opts and opts.title) or 'Menu',
        items = (opts and opts.items) or {}
    })
    return true
end

function janiel.ui.menuClose()
    if not _menuOpen then return end
    closeMenu()
end

RegisterNUICallback('menu_select', function(data, cb)
    cb(1)
    local choice = data and data.id
    if _menuCb then
        pcall(_menuCb, choice, data)
    end
    TriggerEvent('janiel.ui:menu:selected', choice, data)
    closeMenu()
end)

RegisterNUICallback('menu_close', function(data, cb)
    cb(1)
    closeMenu()
end)

RegisterNetEvent('janiel.ui:menu', function(opts)
    janiel.ui.menuOpen(opts)
end)

function janiel_ui_menuOpen(opts)
    return janiel.ui.menuOpen(opts)
end
function janiel_ui_menuClose()
    return janiel.ui.menuClose()
end

exports('openMenu', function(opts)
    return janiel.ui.menuOpen(opts)
end)
exports('closeMenu', function()
    return janiel.ui.menuClose()
end)
