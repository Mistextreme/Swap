if Framework ~= 'tmc' then
    return
end

function janiel.anur.getPlayer(src)
    return TMC.Functions.GetPlayer(src)
end

function janiel.anur.getPlayerByIdentifier(identifier)
    return TMC.Functions.GetPlayerByIdentifier(identifier)
end

function janiel.anur.getIdentifier(src)
    local p = janiel.anur.getPlayer(src)
    if p then
        return p.PlayerData.identifier
    end
    return "standalone-"..tostring(src)
end

function janiel.anur.addMoney(src, amount, account)
    local p = janiel.anur.getPlayer(src)
    if not p then return end
    account = account or "cash"
    p.Functions.AddMoney(account, amount)
end

function janiel.anur.removeMoney(src, amount, account)
    local p = janiel.anur.getPlayer(src)
    if not p then return end
    account = account or "cash"
    p.Functions.RemoveMoney(account, amount)
end

function janiel.player.getJob(src)
    local p = janiel.anur.getPlayer(src)
    if not p then return {name='unemployed', grade=0, label='Unemployed'} end
    
    local j = p.PlayerData and p.PlayerData.job or {}
    return { name = j.name, grade = j.grade or 0, label = j.label or j.name }
end

function janiel.player.getGang(src)
    local p = janiel.anur.getPlayer(src)
    if not p then return {name=nil, grade=0, label=nil} end
    
    local g = p.PlayerData and p.PlayerData.gang or {}
    return { name = g.name, grade = g.grade or 0, label = g.label or g.name }
end

function janiel.player.getMeta(src, key)
    local p = janiel.anur.getPlayer(src)
    if not p then return nil end
    return p.PlayerData and p.PlayerData.metadata and p.PlayerData.metadata[key]
end

function janiel.player.setMeta(src, key, value)
    local p = janiel.anur.getPlayer(src)
    if not p then return false end
    if p.Functions and p.Functions.SetMetaData then
        p.Functions.SetMetaData(key, value)
        return true
    end
    return false
end
