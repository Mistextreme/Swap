if Framework ~= 'vrp' then
    return
end

function janiel.anur.getPlayer(src)
    return vRP.getUserSource(src)
end

function janiel.anur.getPlayerByIdentifier(identifier)
    return vRP.getUserSource(identifier)
end

function janiel.anur.getIdentifier(src)
    local user_id = vRP.getUserId(src)
    if user_id then
        return tostring(user_id)
    end
    return "standalone-"..tostring(src)
end

function janiel.anur.addMoney(src, amount, account)
    local user_id = vRP.getUserId(src)
    if not user_id then return end
    account = account or "wallet"
    if account == "bank" then
        vRP.addBankMoney(user_id, amount)
    else
        vRP.addMoney(user_id, amount)
    end
end

function janiel.anur.removeMoney(src, amount, account)
    local user_id = vRP.getUserId(src)
    if not user_id then return end
    account = account or "wallet"
    if account == "bank" then
        vRP.removeBankMoney(user_id, amount)
    else
        vRP.removeMoney(user_id, amount)
    end
end

function janiel.player.getJob(src)
    local user_id = vRP.getUserId(src)
    if not user_id then return {name='unemployed', grade=0, label='Unemployed'} end
    
    local job = vRP.getUserJob(user_id)
    return { name = job or 'unemployed', grade = 0, label = job or 'Unemployed' }
end

function janiel.player.getGang(src)
    return {name=nil, grade=0, label=nil}
end

function janiel.player.getMeta(src, key)
    local user_id = vRP.getUserId(src)
    if not user_id then return nil end
    return vRP.getUserData(user_id, key)
end

function janiel.player.setMeta(src, key, value)
    local user_id = vRP.getUserId(src)
    if not user_id then return false end
    vRP.setUserData(user_id, key, value)
    return true
end
