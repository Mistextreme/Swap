if Framework ~= 'esx' then
    return
end

function janiel.anur.getPlayer(src)
    return Core.GetPlayerFromId(src)
end

function janiel.anur.getPlayerByIdentifier(identifier)
    return Core.GetPlayerFromIdentifier(identifier)
end

function janiel.anur.getIdentifier(src)
    local p = janiel.anur.getPlayer(src)
    if p then
        return p.identifier
    end
    return "standalone-"..tostring(src)
end

function janiel.anur.addMoney(src, amount, account)
    local p = janiel.anur.getPlayer(src)
    if not p then return end
    account = account or "cash"
    if account == "bank" then
        p.addAccountMoney('bank', amount)
    else
        p.addMoney(amount)
    end
end

function janiel.anur.removeMoney(src, amount, account)
    local p = janiel.anur.getPlayer(src)
    if not p then return end
    account = account or "cash"
    if account == "bank" then
        p.removeAccountMoney('bank', amount)
    else
        p.removeMoney(amount)
    end
end

function janiel.player.getJob(src)
    local p = janiel.anur.getPlayer(src)
    if not p then return {name='unemployed', grade=0, label='Unemployed'} end
    
    local j = p.getJob and p.getJob() or p.job
    j = j or {}
    return { name = j.name, grade = j.grade or 0, label = (j.label or j.name) }
end

function janiel.player.getGang(src)
    return {name=nil, grade=0, label=nil}
end

function janiel.player.getMeta(src, key)
    local p = janiel.anur.getPlayer(src)
    if not p then return nil end
    if p.get and p.get('meta') then
        local meta = p.get('meta')
        return meta and meta[key]
    end
    return nil
end

function janiel.player.setMeta(src, key, value)
    local p = janiel.anur.getPlayer(src)
    if not p then return false end
    if p.set and p.set('meta') then
        local meta = p.get('meta') or {}
        meta[key] = value
        p.set('meta', meta)
        return true
    end
    return false
end
