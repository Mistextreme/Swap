if Framework ~= 'ox' then
    return
end

function janiel.anur.getPlayer(src)
    return Core.GetPlayer(src)
end

function janiel.anur.getPlayerByIdentifier(identifier)
    return Core.GetPlayerByStateId(identifier)
end

function janiel.anur.getIdentifier(src)
    local p = janiel.anur.getPlayer(src)
    if p then
        return p.stateId or p.identifier
    end
    return "standalone-"..tostring(src)
end

function janiel.anur.addMoney(src, amount, account)
    local p = janiel.anur.getPlayer(src)
    if not p then return end
    account = account or "cash"
    p.addMoney(account, amount)
end

function janiel.anur.removeMoney(src, amount, account)
    local p = janiel.anur.getPlayer(src)
    if not p then return end
    account = account or "cash"
    p.removeMoney(account, amount)
end

function janiel.player.getJob(src)
    local p = janiel.anur.getPlayer(src)
    if not p then return {name='unemployed', grade=0, label='Unemployed'} end
    
    local j = p.job or {}
    return { name = j.name, grade = j.grade or 0, label = j.label or j.name }
end

function janiel.player.getGang(src)
    local p = janiel.anur.getPlayer(src)
    if not p then return {name=nil, grade=0, label=nil} end
    
    local g = p.gang or {}
    return { name = g.name, grade = g.grade or 0, label = g.label or g.name }
end

function janiel.player.getMeta(src, key)
    local p = janiel.anur.getPlayer(src)
    if not p then return nil end
    return p.metadata and p.metadata[key]
end

function janiel.player.setMeta(src, key, value)
    local p = janiel.anur.getPlayer(src)
    if not p then return false end
    if p.setMetadata then
        p.setMetadata(key, value)
        return true
    end
    return false
end
