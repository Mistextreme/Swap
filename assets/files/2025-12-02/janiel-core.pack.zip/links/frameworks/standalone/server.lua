if Framework ~= 'standalone' then
    return
end

-- Standalone player storage
local players = {}

function janiel.anur.getPlayer(src)
    return players[src] or { source = src, identifier = "standalone-"..src, data = {} }
end

function janiel.anur.getPlayerByIdentifier(identifier)
    for src, player in pairs(players) do
        if player.identifier == identifier then
            return player
        end
    end
    return nil
end

function janiel.anur.getIdentifier(src)
    return "standalone-"..tostring(src)
end

function janiel.anur.addMoney(src, amount, account)
    local p = janiel.anur.getPlayer(src)
    if not p then return end
    account = account or "cash"
    p.data[account] = (p.data[account] or 0) + amount
end

function janiel.anur.removeMoney(src, amount, account)
    local p = janiel.anur.getPlayer(src)
    if not p then return end
    account = account or "cash"
    p.data[account] = math.max(0, (p.data[account] or 0) - amount)
end

function janiel.player.getJob(src)
    return {name='unemployed', grade=0, label='Unemployed'}
end

function janiel.player.getGang(src)
    return {name=nil, grade=0, label=nil}
end

function janiel.player.getMeta(src, key)
    local p = janiel.anur.getPlayer(src)
    if not p then return nil end
    return p.data and p.data[key]
end

function janiel.player.setMeta(src, key, value)
    local p = janiel.anur.getPlayer(src)
    if not p then return false end
    if not p.data then p.data = {} end
    p.data[key] = value
    return true
end

-- Track player joins/leaves
AddEventHandler('playerJoining', function(source)
    players[source] = {
        source = source,
        identifier = "standalone-"..source,
        data = {}
    }
end)

AddEventHandler('playerDropped', function(reason)
    local source = source
    players[source] = nil
end)
