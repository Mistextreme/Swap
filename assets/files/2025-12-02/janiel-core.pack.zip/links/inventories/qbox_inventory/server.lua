if Framework ~= 'qbox' then
    return
end

function janiel.inv.add(src, item, count, metadata)
    count = count or 1
    local p = nil
    
    -- Try QBox direct export first
    if GetResourceState('qbx_core') == 'started' then
        local success, player = pcall(function()
            return exports.qbx_core:GetPlayer(src)
        end)
        if success and player then
            p = player
        end
    end
    
    -- Fallback to janiel.anur.getPlayer
    if not p then
        p = janiel.anur.getPlayer(src)
    end
    
    if not p then 
        return false 
    end
    
    local success = pcall(function()
        return p.Functions.AddItem(item, count)
    end)
    return success
end

function janiel.inv.remove(src, item, count, metadata)
    count = count or 1
    local p = nil
    
    -- Try QBox direct export first
    if GetResourceState('qbx_core') == 'started' then
        local success, player = pcall(function()
            return exports.qbx_core:GetPlayer(src)
        end)
        if success and player then
            p = player
        end
    end
    
    -- Fallback to janiel.anur.getPlayer
    if not p then
        p = janiel.anur.getPlayer(src)
    end
    
    if not p then 
        return false 
    end
    
    local success = pcall(function()
        return p.Functions.RemoveItem(item, count)
    end)
    return success
end

function janiel.inv.count(src, item, metadata)
    local p = nil
    
    -- Try QBox direct export first
    if GetResourceState('qbx_core') == 'started' then
        local success, player = pcall(function()
            return exports.qbx_core:GetPlayer(src)
        end)
        if success and player then
            p = player
        end
    end
    
    -- Fallback to janiel.anur.getPlayer
    if not p then
        p = janiel.anur.getPlayer(src)
    end
    
    if not p then 
        return 0 
    end
    
    if p.PlayerData and p.PlayerData.items then
        local total = 0
        for _, v in pairs(p.PlayerData.items) do
            if v and v.name == item then
                total = total + (v.count or 0)
            end
        end
        return total
    end
    return 0
end
