if not (GetResourceState('ps-inventory') == 'started') then
    return
end

function janiel.inv.add(src, item, count, metadata)
    count = count or 1
    local success, response = exports['ps-inventory']:AddItem(src, item, count, metadata)
    return success
end

function janiel.inv.remove(src, item, count, metadata)
    count = count or 1
    local success, response = exports['ps-inventory']:RemoveItem(src, item, count)
    return success
end

function janiel.inv.count(src, item, metadata)
    local data = exports['ps-inventory']:GetItem(src, item)
    if data then
        return data.count or data.amount or 0
    end
    return 0
end
