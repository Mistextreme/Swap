if Framework ~= 'esx' then
    return
end

function janiel.inv.add(src, item, count, metadata)
    count = count or 1
    local Player = janiel.anur.getPlayer(src)
    if not Player then 
        return false 
    end
    
    -- Try ESX addoninventory first
    if GetResourceState('esx_addoninventory') == 'started' then
        local success = pcall(function()
            exports['esx_addoninventory']:AddItem(src, 'chemistry', item, count)
            return true
        end)
        if success then return true end
    end
    
    -- Use ESX player inventory
    Player.addInventoryItem(item, count, {})
    return true
end

function janiel.inv.remove(src, item, count, metadata)
    count = count or 1
    local Player = janiel.anur.getPlayer(src)
    if not Player then 
        return false 
    end
    
    -- Try ESX addoninventory first
    if GetResourceState('esx_addoninventory') == 'started' then
        local success = pcall(function()
            exports['esx_addoninventory']:RemoveItem(src, 'chemistry', item, count)
            return true
        end)
        if success then return true end
    end
    
    -- Use ESX player inventory
    Player.removeInventoryItem(item, count, {})
    return true
end

function janiel.inv.count(src, item, metadata)
    local Player = janiel.anur.getPlayer(src)
    if not Player then 
        return 0 
    end
    
    if Player.inventory then
        for _, v in ipairs(Player.inventory) do
            if v.name == item then
                return v.count or 0
            end
        end
    end
    return 0
end
