if not (GetResourceState('qs-inventory') == 'started') then
    return
end

function janiel.inv.add(src, item, count, metadata)
    count = count or 1
    local success = exports['qs-inventory']:AddItem(src, item, count, metadata)
    return success
end

function janiel.inv.remove(src, item, count, metadata)
    count = count or 1
    local success = exports['qs-inventory']:RemoveItem(src, item, count)
    return success
end

function janiel.inv.count(src, item, metadata)
    local data = exports['qs-inventory']:GetItem(src, item)
    if data then
        return data.count or data.amount or 0
    end
    return 0
end
