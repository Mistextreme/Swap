if not (GetResourceState('codem-inventory') == 'started') then
    return
end

function janiel.inv.add(src, item, count, metadata)
    count = count or 1
    local success = exports['codem-inventory']:AddItem(src, item, count, metadata)
    return success
end

function janiel.inv.remove(src, item, count, metadata)
    count = count or 1
    local success = exports['codem-inventory']:RemoveItem(src, item, count)
    return success
end

function janiel.inv.count(src, item, metadata)
    local itemData = exports['codem-inventory']:GetItemByName(src, item)
    if itemData then
        return itemData.amount or 0
    end
    return 0
end
