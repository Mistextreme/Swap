if not (Framework == 'qb' and GetResourceState('qb-inventory') == 'started') then
    return
end

function janiel.inv.add(src, item, count, metadata)
    count = count or 1
    local p = janiel.anur.getPlayer(src)
    if not p then return false end
    return p.Functions.AddItem(item, count)
end

function janiel.inv.remove(src, item, count, metadata)
    count = count or 1
    local p = janiel.anur.getPlayer(src)
    if not p then return false end
    return p.Functions.RemoveItem(item, count)
end

function janiel.inv.count(src, item, metadata)
    local p = janiel.anur.getPlayer(src)
    if not p then 
        return 0 
    end
    
    if p.PlayerData and p.PlayerData.items then
        local total = 0
        for _, v in pairs(p.PlayerData.items) do
            if v and v.name == item then
                total = total + (v.amount or 0)
            end
        end
        return total
    end
    return 0
end
