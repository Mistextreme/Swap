if not (GetResourceState('ox_inventory') == 'started') then
    return
end

local ox = exports['ox_inventory']

function janiel.inv.add(src, item, count, metadata)
    count = count or 1
    if ox and ox.AddItem then
        return ox:AddItem(src, item, count, metadata)
    else
        local success = pcall(function()
            return exports['ox_inventory']:AddItem(src, item, count, metadata)
        end)
        return success
    end
end

function janiel.inv.remove(src, item, count, metadata)
    count = count or 1
    if ox and ox.RemoveItem then
        return ox:RemoveItem(src, item, count, metadata)
    else
        local success = pcall(function()
            return exports['ox_inventory']:RemoveItem(src, item, count, metadata)
        end)
        return success
    end
end

function janiel.inv.count(src, item, metadata)
    if ox and ox.GetItemCount then
        local count = ox:GetItemCount(src, item, metadata) or 0
        return count
    elseif ox and ox.GetItem then
        local it = ox:GetItem(src, item, metadata)
        local count = (it and it.count) or 0
        return count
    else
        local success, count = pcall(function()
            return exports['ox_inventory']:GetItemCount(src, item, metadata) or 0
        end)
        if success then
            return count
        else
            return 0
        end
    end
end
