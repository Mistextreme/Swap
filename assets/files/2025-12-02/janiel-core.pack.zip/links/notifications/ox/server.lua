if Framework ~= 'ox' then
    return
end

function janiel.notify.send(src, message, ntype, title)
    ntype = ntype or 'info'
    TriggerClientEvent('ox:notify', src, {
        title = title or 'Notification',
        description = message,
        type = ntype,
        duration = 5000
    })
end

function janiel.notify.sendAll(message, ntype, title)
    ntype = ntype or 'info'
    TriggerClientEvent('ox:notify', -1, {
        title = title or 'Notification',
        description = message,
        type = ntype,
        duration = 5000
    })
end

function janiel.notify.sendGroup(sources, message, ntype, title)
    ntype = ntype or 'info'
    for _, src in ipairs(sources) do
        TriggerClientEvent('ox:notify', src, {
            title = title or 'Notification',
            description = message,
            type = ntype,
            duration = 5000
        })
    end
end
