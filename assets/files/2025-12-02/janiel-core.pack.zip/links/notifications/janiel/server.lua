function janiel.notify.send(src, message, ntype, title)
    ntype = ntype or 'primary'
    title = title or ''
    TriggerClientEvent('janiel.anur:notify', src, message, ntype, title)
end

function janiel.notify.sendAll(message, ntype, title)
    ntype = ntype or 'primary'
    title = title or ''
    TriggerClientEvent('janiel.anur:notify', -1, message, ntype, title)
end

function janiel.notify.sendGroup(sources, message, ntype, title)
    ntype = ntype or 'primary'
    title = title or ''
    for _, src in ipairs(sources) do
        TriggerClientEvent('janiel.anur:notify', src, message, ntype, title)
    end
end
