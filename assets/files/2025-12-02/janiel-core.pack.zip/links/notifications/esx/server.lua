if Framework ~= 'esx' then
    return
end

function janiel.notify.send(src, message, ntype, title)
    TriggerClientEvent('esx:showNotification', src, message)
end

function janiel.notify.sendAll(message, ntype, title)
    TriggerClientEvent('esx:showNotification', -1, message)
end

function janiel.notify.sendGroup(sources, message, ntype, title)
    for _, src in ipairs(sources) do
        TriggerClientEvent('esx:showNotification', src, message)
    end
end
