if Framework ~= 'qb' then
    return
end

function janiel.notify.send(src, message, ntype, title)
    ntype = ntype or 'primary'
    TriggerClientEvent('QBCore:Notify', src, message, ntype, title)
end

function janiel.notify.sendAll(message, ntype, title)
    ntype = ntype or 'primary'
    TriggerClientEvent('QBCore:Notify', -1, message, ntype, title)
end

function janiel.notify.sendGroup(sources, message, ntype, title)
    ntype = ntype or 'primary'
    for _, src in ipairs(sources) do
        TriggerClientEvent('QBCore:Notify', src, message, ntype, title)
    end
end
