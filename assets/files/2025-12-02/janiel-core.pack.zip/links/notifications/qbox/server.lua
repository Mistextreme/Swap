if Framework ~= 'qbox' then
    return
end

function janiel.notify.send(src, message, ntype, title)
    ntype = ntype or 'primary'
    TriggerClientEvent('qbx_core:Notify', src, message, ntype, title)
end

function janiel.notify.sendAll(message, ntype, title)
    ntype = ntype or 'primary'
    TriggerClientEvent('qbx_core:Notify', -1, message, ntype, title)
end

function janiel.notify.sendGroup(sources, message, ntype, title)
    ntype = ntype or 'primary'
    for _, src in ipairs(sources) do
        TriggerClientEvent('qbx_core:Notify', src, message, ntype, title)
    end
end
