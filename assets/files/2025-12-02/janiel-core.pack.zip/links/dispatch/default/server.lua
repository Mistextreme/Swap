local activeDispatches = {}
local dispatchId = 0

local function getNextDispatchId()
    dispatchId = dispatchId + 1
    return dispatchId
end

function janiel.dispatch.create(data)
    local id = getNextDispatchId()
    
    activeDispatches[id] = {
        id = id,
        title = data.title or 'Dispatch',
        description = data.description or '',
        coords = data.coords or vector3(0, 0, 0),
        icon = data.icon or 'fas fa-exclamation-triangle',
        color = data.color or 'red',
        duration = data.duration or 30000,
        createdAt = GetGameTimer(),
        data = data.data or {}
    }
    
    SetTimeout(data.duration or 30000, function()
        activeDispatches[id] = nil
    end)
    
    return id
end

function janiel.dispatch.get(id)
    return activeDispatches[id]
end

function janiel.dispatch.getAll()
    return activeDispatches
end

function janiel.dispatch.remove(id)
    activeDispatches[id] = nil
end

function janiel.dispatch.clear()
    activeDispatches = {}
end

-- Export functions
exports('janiel_dispatch_create', function(data)
    return janiel.dispatch.create(data)
end)

exports('janiel_dispatch_get', function(id)
    return janiel.dispatch.get(id)
end)

exports('janiel_dispatch_getAll', function()
    return janiel.dispatch.getAll()
end)

exports('janiel_dispatch_remove', function(id)
    return janiel.dispatch.remove(id)
end)

exports('janiel_dispatch_clear', function()
    return janiel.dispatch.clear()
end)
