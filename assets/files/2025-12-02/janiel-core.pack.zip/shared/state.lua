janiel = janiel or {}
janiel.state = janiel.state or {}

-- Global state helpers (replicated to all clients)
function janiel.state.setGlobal(key, value)
    GlobalState[key] = value
end

function janiel.state.getGlobal(key)
    return GlobalState[key]
end
