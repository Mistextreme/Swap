janiel = janiel or {}

local idseq = 0
local timers = {}

local function nextId()
    idseq = idseq + 1
    return idseq
end

local function clear(id)
    local t = timers[id]
    if not t then return end
    t.cancelled = true
    timers[id] = nil
end

local function setTimeout(fn, ms)
    local id = nextId()
    timers[id] = { cancelled = false }
    SetTimeout(ms or 0, function()
        if timers[id] and not timers[id].cancelled then
            pcall(fn)
        end
        timers[id] = nil
    end)
    return id
end

local function setInterval(fn, ms)
    local id = nextId()
    timers[id] = { cancelled = false }
    CreateThread(function()
        local delay = ms or 0
        while timers[id] and not timers[id].cancelled do
            pcall(fn)
            Wait(delay)
        end
        timers[id] = nil
    end)
    return id
end

janiel.time = {
    setTimeout = setTimeout,
    setInterval = setInterval,
    clear = clear
}
