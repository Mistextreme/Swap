Config = {}

-- Default locale for all scripts using janiel-core i18n
Config.Locale = "en"

-- NotifyMode options:
-- "auto"   -> use detected framework notify (QBCore/QBox/ESX) or print fallback
-- "custom" -> use this resource's HTML notify (NUI)
Config.NotifyMode = "custom"

-- Custom notify defaults
Config.Notify = {
    Position = "top-right", -- top-left, top-right, bottom-left, bottom-right
    Duration = 3500,         -- milliseconds
    MaxStack = 4,            -- max visible toasts
    UseFA = false            -- load Font Awesome icons from CDN and use <i> classes
}

-- Inventory provider autodetect config
-- Provider options:
-- "auto" -> autodetect (ox_inventory > qb > esx > standalone)
-- "ox"   -> use ox_inventory
-- "qb"   -> use qb-core player inventory
-- "esx"  -> use es_extended inventory
-- "standalone" -> minimal no-op/fallback
Config.Inventory = {
    Provider = "auto"
}

-- Target provider autodetect
-- Provider options:
-- "auto" -> autodetect (ox_target > qb-target > none)
-- "ox"   -> use ox_target
-- "qb"   -> use qb-target
-- "none" -> disable external target (use our separate interact system only)
Config.Target = {
    Provider = "auto"
}

-- Interact system toggle (our custom, interact-main style)
Config.Interact = {
    Enabled = true
}
