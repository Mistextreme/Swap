local I18N = {}
I18N.current = (Config and Config.Locale) or 'en'
I18N.bundles = {}

function I18N.setLocale(loc)
  I18N.current = loc or I18N.current
end

function I18N.register(resource, locale, dict)
  local b = I18N.bundles
  b[resource] = b[resource] or {}
  b[resource][locale] = dict
end

function I18N.t(resource, key, vars)
  local r = I18N.bundles[resource]
  local d = r and r[I18N.current]
  local val = d and d[key]
  if not val and r then
    d = r['en']
    val = d and d[key]
  end
  if type(val) == 'string' then
    if vars then
      for k, v in pairs(vars) do
        val = val:gsub('{'..k..'}', tostring(v))
      end
    end
    return val
  end
  return key
end

-- also expose via janiel for in-resource access (optional)
janiel = janiel or {}
janiel.i18n = I18N

-- Export wrappers so other resources can use i18n via exports
function janiel_i18n_register(resource, locale, dict)
  return I18N.register(resource, locale, dict)
end
function janiel_i18n_setLocale(loc)
  return I18N.setLocale(loc)
end
function janiel_i18n_t(resource, key, vars)
  return I18N.t(resource, key, vars)
end
