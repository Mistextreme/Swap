janiel = janiel or {}
janiel.inv = janiel.inv or {}
janiel.inv.meta = janiel.inv.meta or {}

local M = janiel.inv.meta

local function clone(t)
    local n = {}
    for k,v in pairs(t or {}) do n[k] = v end
    return n
end

function M.ensure(meta)
    return clone(meta or {})
end

-- Common helpers used in ox_inventory items
function M.withLabel(meta, label)
    meta = M.ensure(meta); meta.label = label; return meta
end

function M.withDescription(meta, description)
    meta = M.ensure(meta); meta.description = description; return meta
end

function M.withQuality(meta, quality)
    meta = M.ensure(meta); meta.quality = quality; return meta
end

function M.withDurability(meta, durability)
    meta = M.ensure(meta); meta.durability = durability; return meta
end

function M.withSerial(meta, serial)
    meta = M.ensure(meta); meta.serial = serial; return meta
end

function M.withAmmo(meta, ammo)
    meta = M.ensure(meta); meta.ammo = ammo; return meta
end

function M.merge(a, b)
    local out = clone(a or {})
    for k,v in pairs(b or {}) do out[k] = v end
    return out
end

-- Generic setter
function M.set(meta, key, value)
    meta = M.ensure(meta); meta[key] = value; return meta
end

return M
