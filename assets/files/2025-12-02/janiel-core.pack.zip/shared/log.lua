janiel = janiel or {}

local levels = { trace=0, debug=1, info=2, warn=3, error=4 }
local colors = { trace="^5", debug="^5", info="^2", warn="^3", error="^1" }

local function getMinLevel()
    local s = GetConvar and GetConvar('janiel:logLevel', '') or ''
    if s == '' and Config and Config.LogLevel then s = Config.LogLevel end
    s = (s or 'info'):lower()
    return levels[s] or levels.info
end

local function emit(lvl, ...)
    local min = getMinLevel()
    local n = levels[lvl] or levels.info
    if n < min then return end
    local c = colors[lvl] or "^7"
    local args = {...}
    local prefix = string.format("%s[janiel.%s]^0", c, lvl)
    print(prefix, table.unpack(args))
end

janiel.log = {
    trace = function(...) emit('trace', ...) end,
    debug = function(...) emit('debug', ...) end,
    info  = function(...) emit('info',  ...) end,
    warn  = function(...) emit('warn',  ...) end,
    error = function(...) emit('error', ...) end,
}
