fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'janiel-core'
description 'Janiel Developments Core/Lib with configurable notify'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

shared_scripts {
    '@ox_lib/init.lua',
    'shared/locales.lua',
    'shared/config.lua',
    'shared/log.lua',
    'shared/time.lua',
    'shared/state.lua',
    'shared/inv_meta.lua'
}

client_scripts {
    'client/init.lua',
    'client/main.lua',
    'client/callbacks.lua',
    'client/keybind.lua',
    'client/progress.lua',
    'client/hint.lua',
    'client/target.lua',
    'client/interact.lua',
    'client/npc.lua',
    'client/menu.lua'
}

server_scripts {
    'server/main.lua',
    'server/callbacks.lua',
    'server/commands.lua',
    'server/tests.lua',
    'server/version.lua'
}

client_exports {
    'janiel_i18n_register',
    'janiel_i18n_setLocale',
    'janiel_i18n_t',
    'janiel_progress'
}

server_exports {
    'janiel_inv_add',
    'janiel_inv_remove',
    'janiel_inv_count',
    'janiel_notify_send',
    'janiel_notify_sendAll',
    'janiel_notify_sendGroup',
    'janiel_dispatch_create',
    'janiel_dispatch_get',
    'janiel_dispatch_getAll',
    'janiel_dispatch_remove',
    'janiel_dispatch_clear',
    'janiel_anur_addMoney',
    'janiel_anur_removeMoney',
    'janiel_anur_getPlayer',
    'janiel_anur_getPlayerByIdentifier',
    'janiel_anur_getIdentifier'
}


escrow_ignore {
    'html/**',
    'locales/*.lua',
    'shared/**',
    'client/**',
    'links/**',
    'server/callbacks.lua',
    'server/tests.lua'
}

dependency '/assetpacks'